package Unidad_1;

import java.awt.EventQueue;


import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JLabel;

public class Ejemplo03_a2233336147 extends JFrame {

		static JLabel La,Lb;
		static JButton Bboton;
		
		public Ejemplo03_a2233336147()
		{
		this.setLayout(null);
		this.setBounds (10, 10, 300, 300);
		La = new JLabel("el triangulo de base 5 y de altura 2"); La.setBounds (10, 10, 200, 30);
		Lb = new JLabel();
		Lb.setBounds (10, 100, 200, 30);
		Bboton = new JButton("Calcular");
		Bboton.setBounds (10, 50, 100, 30);
		this.add(La);
		this.add(Lb);
		this.add(Bboton);
		}
		
		
		
		public static void main(String[] args) {
			Ejemplo03_a2233336147 ventana=new Ejemplo03_a2233336147();
			ventana.setVisible(true);
			Lb.setText("El area del triangulo es 5");
		}

	}
