package Unidad_1;


public class ejecutar06_d {
	
	public static void main(String[] args) {
		
		Controlador6d clase=new Controlador6d();
	}

	

}
