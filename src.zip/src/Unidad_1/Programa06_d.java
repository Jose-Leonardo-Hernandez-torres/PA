package Unidad_1;


import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.JList;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.DefaultListModel;

public class Programa06_d extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel Panelprincipal;
	public JList Lcuidades;
	public JComboBox Cciudades;
	String[] Ciudadesm={"Tampico", "cd de Mexico", "Monterrey", "Guadalajara", "Acapulco"};
	String[] CiudadesI={"Tampico", "cd de Mexico", "Monterrey", "Guadalajara", "New York"};
	
	public DefaultListModel lista;
	public JButton Bsalir,BciudadI,Bciudadm;
	

	public void Inicializar() {
		
		for(String Ciudad:this.Ciudadesm)
			
		lista=new DefaultListModel();
		for(String Ciudad:this.CiudadesI)
			this.lista.addElement(Ciudad);
		
		this.Lcuidades.setModel(this.lista);
	}
	

	
	public Programa06_d() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		Panelprincipal = new JPanel();
		Panelprincipal.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(Panelprincipal);
		GridBagLayout gbl_PanelCuidadm = new GridBagLayout();
		gbl_PanelCuidadm.columnWidths = new int[]{0, 0};
		gbl_PanelCuidadm.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0};
		gbl_PanelCuidadm.columnWeights = new double[]{1.0, Double.MIN_VALUE};
		gbl_PanelCuidadm.rowWeights = new double[]{0.0, 1.0, 1.0, 1.0, 0.0, 0.0, Double.MIN_VALUE};
		Panelprincipal.setLayout(gbl_PanelCuidadm);
		
		JPanel PanelCuidadm = new JPanel();
		GridBagConstraints gbc_PanelCuidadm = new GridBagConstraints();
		gbc_PanelCuidadm.insets = new Insets(0, 0, 5, 0);
		gbc_PanelCuidadm.fill = GridBagConstraints.BOTH;
		gbc_PanelCuidadm.gridx = 0;
		gbc_PanelCuidadm.gridy = 1;
		Panelprincipal.add(PanelCuidadm, gbc_PanelCuidadm);
		GridBagLayout gbl_PanelCuidadm1 = new GridBagLayout();
		gbl_PanelCuidadm1.columnWidths = new int[]{0, 0, 0, 0};
		gbl_PanelCuidadm1.rowHeights = new int[]{0, 0};
		gbl_PanelCuidadm1.columnWeights = new double[]{0.0, 0.0, 1.0, Double.MIN_VALUE};
		gbl_PanelCuidadm1.rowWeights = new double[]{0.0, Double.MIN_VALUE};
		PanelCuidadm.setLayout(gbl_PanelCuidadm1);
		
		JLabel lblNewLabel = new JLabel(" Ciudades Mexico");
		GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
		gbc_lblNewLabel.insets = new Insets(0, 0, 0, 5);
		gbc_lblNewLabel.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel.gridx = 1;
		gbc_lblNewLabel.gridy = 0;
		PanelCuidadm.add(lblNewLabel, gbc_lblNewLabel);
		
		Cciudades = new JComboBox();
		GridBagConstraints gbc_Cciudades = new GridBagConstraints();
		gbc_Cciudades.fill = GridBagConstraints.HORIZONTAL;
		gbc_Cciudades.gridx = 2;
		gbc_Cciudades.gridy = 0;
		PanelCuidadm.add(Cciudades, gbc_Cciudades);
		
		JPanel PanelCiudadesP = new JPanel();
		GridBagConstraints gbc_PanelCiudadesP = new GridBagConstraints();
		gbc_PanelCiudadesP.insets = new Insets(0, 0, 5, 0);
		gbc_PanelCiudadesP.fill = GridBagConstraints.BOTH;
		gbc_PanelCiudadesP.gridx = 0;
		gbc_PanelCiudadesP.gridy = 2;
		Panelprincipal.add(PanelCiudadesP, gbc_PanelCiudadesP);
		GridBagLayout gbl_PanelCiudadesP = new GridBagLayout();
		gbl_PanelCiudadesP.columnWidths = new int[]{0, 0, 0, 0};
		gbl_PanelCiudadesP.rowHeights = new int[]{0, 0};
		gbl_PanelCiudadesP.columnWeights = new double[]{0.0, 0.0, 1.0, Double.MIN_VALUE};
		gbl_PanelCiudadesP.rowWeights = new double[]{1.0, Double.MIN_VALUE};
		PanelCiudadesP.setLayout(gbl_PanelCiudadesP);
		
		JLabel lblNewLabel_1 = new JLabel("Ciudades Importantes");
		GridBagConstraints gbc_lblNewLabel_1 = new GridBagConstraints();
		gbc_lblNewLabel_1.insets = new Insets(0, 0, 0, 5);
		gbc_lblNewLabel_1.gridx = 1;
		gbc_lblNewLabel_1.gridy = 0;
		PanelCiudadesP.add(lblNewLabel_1, gbc_lblNewLabel_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		GridBagConstraints gbc_scrollPane = new GridBagConstraints();
		gbc_scrollPane.fill = GridBagConstraints.BOTH;
		gbc_scrollPane.gridx = 2;
		gbc_scrollPane.gridy = 0;
		PanelCiudadesP.add(scrollPane, gbc_scrollPane);
		
		Lcuidades= new JList();
		scrollPane.setViewportView(Lcuidades);
		
		JPanel PanelBotones = new JPanel();
		GridBagConstraints gbc_PanelBotones = new GridBagConstraints();
		gbc_PanelBotones.insets = new Insets(0, 0, 5, 0);
		gbc_PanelBotones.fill = GridBagConstraints.BOTH;
		gbc_PanelBotones.gridx = 0;
		gbc_PanelBotones.gridy = 3;
		Panelprincipal.add(PanelBotones, gbc_PanelBotones);
		GridBagLayout gbl_PanelBotones = new GridBagLayout();
		gbl_PanelBotones.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0, 0};
		gbl_PanelBotones.rowHeights = new int[]{0, 0};
		gbl_PanelBotones.columnWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		gbl_PanelBotones.rowWeights = new double[]{0.0, Double.MIN_VALUE};
		PanelBotones.setLayout(gbl_PanelBotones);
		
		Bciudadm = new JButton("Ciudades Mexicanas");
		GridBagConstraints gbc_Bciudadm = new GridBagConstraints();
		gbc_Bciudadm.insets = new Insets(0, 0, 0, 5);
		gbc_Bciudadm.gridx = 2;
		gbc_Bciudadm.gridy = 0;
		PanelBotones.add(Bciudadm, gbc_Bciudadm);
		
		BciudadI = new JButton("Ciudades internacionales");
		GridBagConstraints gbc_BciudadI = new GridBagConstraints();
		gbc_BciudadI.insets = new Insets(0, 0, 0, 5);
		gbc_BciudadI.gridx = 4;
		gbc_BciudadI.gridy = 0;
		PanelBotones.add(BciudadI, gbc_BciudadI);
		
		Bsalir = new JButton("Salir");
		GridBagConstraints gbc_Bsalir = new GridBagConstraints();
		gbc_Bsalir.gridx = 6;
		gbc_Bsalir.gridy = 0;
		PanelBotones.add(Bsalir, gbc_Bsalir);
		
		this.Inicializar();
	}

}
