package Unidad_1;

import java.awt.CardLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;



public class Programa07_b2 extends JInternalFrame {
	
	private static final long serialVersionUTD = 1L;
	private JPanel contentPane;	
	public JButton Bsalir;
	
	public Programa07_b2() {
		
		setMaximizable(true);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new CardLayout(0, 0)); 
		Bsalir = new JButton("Salida");
		
		contentPane.add(Bsalir);
	}
}
