package Unidad_1;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class Ejemplo01_a2233336147_c extends JFrame {

	public Ejemplo01_a2233336147_c() {
		this.setTitle("2024-3");
		this.setBounds(10, 20, 400, 300);
	}
	
	public static void main(String[] args) {
		
		Ejemplo01_a2233336147_c ventana = new Ejemplo01_a2233336147_c();
		ventana.setVisible(true);
	}

}
