package Unidad_1;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;

public class Ejemplo02_a2233336147 extends JFrame {
		JLabel a,b;
		
			public  Ejemplo02_a2233336147() {
			this.setTitle("2024-3");
			this.setBounds(10,20,300,200);
			a= new JLabel ("El tringulo de base 2*5");
			a.setBounds(10,10,200,30);
			b=new JLabel();
			b.setBounds(10,50,300,30);
			add(a);
			
		}
		
		public static void main(String[] args) {
			Ejemplo02_a2233336147 ventana=new  Ejemplo02_a2233336147();
		ventana.setVisible(true);
			
		}

	}
