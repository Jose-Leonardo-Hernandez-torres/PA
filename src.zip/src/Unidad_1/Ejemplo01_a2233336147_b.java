package Unidad_1;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class Ejemplo01_a2233336147_b extends JFrame {

	
	public static void main(String[] args) {
		JFrame ventana = new JFrame();
		ventana.setTitle("2020-3");
		ventana.setBounds(100, 100, 450, 300);
		ventana.setVisible(true);
				
	}

}
