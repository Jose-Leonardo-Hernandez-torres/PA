package Unidad_1;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Programa02_a2233336147 extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField TEvaluacion;
	private JTextField Tnumero;
	private JButton Bevaluar,BSalir;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Programa02_a2233336147 frame = new Programa02_a2233336147();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Programa02_a2233336147() {
		setTitle("Programa 02 a2233336147");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("introduce el numero");
		lblNewLabel.setBounds(27, 27, 104, 13);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("evaluacion");
		lblNewLabel_1.setBounds(27, 87, 45, 13);
		contentPane.add(lblNewLabel_1);
		
		Bevaluar = new JButton("Evaluar");
		Bevaluar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if ((!Tnumero.getText().isEmpty())&&(!Tnumero.getText().isBlank()))
				{
					double num = Double.parseDouble(Tnumero.getText());
					if(num>0)
						TEvaluacion.setText("positivo");
					else
						if(num<0)
							TEvaluacion.setText("negativo");
						else
							TEvaluacion.setText("cero");
				}
			}
		});
		Bevaluar.setBounds(296, 37, 85, 21);
		contentPane.add(Bevaluar);
		
		BSalir = new JButton("Salir");
		BSalir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Programa02_a2233336147.this.dispose();
			}
		});
		BSalir.setBounds(247, 172, 85, 21);
		contentPane.add(BSalir);
		
		TEvaluacion = new JTextField();
		TEvaluacion.setBounds(145, 84, 96, 19);
		contentPane.add(TEvaluacion);
		TEvaluacion.setColumns(10);
		
		Tnumero = new JTextField();
		Tnumero.setBounds(145, 24, 96, 19);
		contentPane.add(Tnumero);
		Tnumero.setColumns(10);
	}

}
