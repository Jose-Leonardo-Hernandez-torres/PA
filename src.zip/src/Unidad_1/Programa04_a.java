package Unidad_1;

import java.awt.EventQueue;


import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.GridBagLayout;
import javax.swing.JLabel;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.CardLayout;

public class Programa04_a extends JFrame implements ActionListener {

	private static final long serialVersionUID = 1L;
	private JPanel Principal;
	private JTextField Taltura;
	private JTextField Tbase;
	private JTextField Tarea;
	private JRadioButton Rrectangulo,Rtriangulo;
	private JButton Bsalir,Barea,Bperimetro;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Programa04_a frame = new Programa04_a();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Programa04_a() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		Principal = new JPanel();
		Principal.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(Principal);
		GridBagLayout gbl_principal = new GridBagLayout();
		gbl_principal.columnWidths = new int[]{0, 222, 0, 0};
		gbl_principal.rowHeights = new int[] {33, 33, 33, 33, 33, 33};
		gbl_principal.columnWeights = new double[]{0.0, 1.0, 0.0, Double.MIN_VALUE};
		gbl_principal.rowWeights = new double[]{0.0, 1.0, 1.0, 1.0, 1.0, 1.0};
		Principal.setLayout(gbl_principal);
		
		JPanel panel = new JPanel();
		GridBagConstraints gbc_panel = new GridBagConstraints();
		gbc_panel.insets = new Insets(0, 0, 5, 5);
		gbc_panel.fill = GridBagConstraints.BOTH;
		gbc_panel.gridx = 1;
		gbc_panel.gridy = 1;
		Principal.add(panel, gbc_panel);
		
		JLabel lblNewLabel = new JLabel("Elige una figura:");
		panel.add(lblNewLabel);
		
		Rrectangulo = new JRadioButton("Rectangulo");
		panel.add(Rrectangulo);
		Rrectangulo.setSelected(true);
		
		
		
		 Rtriangulo = new JRadioButton("Triangulo");
		panel.add(Rtriangulo);
		this.Rtriangulo.setSelected(false);
		
		Rrectangulo.addActionListener(this);
		Rtriangulo.addActionListener(this);
		
		JPanel panel_1 = new JPanel();
		GridBagConstraints gbc_panel_1 = new GridBagConstraints();
		gbc_panel_1.anchor = GridBagConstraints.WEST;
		gbc_panel_1.insets = new Insets(0, 0, 5, 5);
		gbc_panel_1.fill = GridBagConstraints.VERTICAL;
		gbc_panel_1.gridx = 1;
		gbc_panel_1.gridy = 2;
		Principal.add(panel_1, gbc_panel_1);
		
		JLabel lblNewLabel_1 = new JLabel("Introduce el valor de altura:");
		panel_1.add(lblNewLabel_1);
		
		Taltura = new JTextField();
		panel_1.add(Taltura);
		Taltura.setColumns(10);
		
		JPanel panel_2 = new JPanel();
		GridBagConstraints gbc_panel_2 = new GridBagConstraints();
		gbc_panel_2.anchor = GridBagConstraints.WEST;
		gbc_panel_2.insets = new Insets(0, 0, 5, 5);
		gbc_panel_2.fill = GridBagConstraints.VERTICAL;
		gbc_panel_2.gridx = 1;
		gbc_panel_2.gridy = 3;
		Principal.add(panel_2, gbc_panel_2);
		
		JLabel lblNewLabel_1_1 = new JLabel("Introduce el valor de la base:");
		panel_2.add(lblNewLabel_1_1);
		
		Tbase = new JTextField();
		Tbase.setColumns(10);
		panel_2.add(Tbase);
		
		JPanel panel_4 = new JPanel();
		GridBagConstraints gbc_panel_4 = new GridBagConstraints();
		gbc_panel_4.insets = new Insets(0, 0, 5, 5);
		gbc_panel_4.fill = GridBagConstraints.BOTH;
		gbc_panel_4.gridx = 1;
		gbc_panel_4.gridy = 4;
		Principal.add(panel_4, gbc_panel_4);
		
		 Barea = new JButton("Calcular area");
		panel_4.add(Barea);
		this.Barea.addActionListener(this);
		
	     Bperimetro = new JButton("Calcular perimetro");
		panel_4.add(Bperimetro);
		this.Bperimetro.addActionListener(this);
		
	     Bsalir = new JButton("Salir");
		panel_4.add(Bsalir);
		this.Bsalir.addActionListener(this);
		
		JPanel panel_3 = new JPanel();
		GridBagConstraints gbc_panel_3 = new GridBagConstraints();
		gbc_panel_3.insets = new Insets(0, 0, 0, 5);
		gbc_panel_3.fill = GridBagConstraints.BOTH;
		gbc_panel_3.gridx = 1;
		gbc_panel_3.gridy = 5;
		Principal.add(panel_3, gbc_panel_3);
		panel_3.setLayout(new CardLayout(0, 0));
		
		Tarea = new JTextField();
		panel_3.add(Tarea, "name_191424426290500");
		Tarea.setColumns(10);
	}

	
	public boolean Novacios(JTextField a,JTextField b) {
		if(!a.getText().trim().isBlank() && (!b.getText().trim().isBlank())) 
			return true;
		else 
			return false;
			
		
	}
	
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==this.Rrectangulo)
			this.Rtriangulo.setSelected(false);
		else 
			if (e.getSource()==this.Rtriangulo)
				this.Rrectangulo.setSelected(false);
		
		if(e.getSource()==this.Barea) {
			if(Novacios(this.Taltura,this.Tbase))
			{
				double h,b,a;
				h=Double.parseDouble(this.Taltura.getText());
				b=Double.parseDouble(this.Tbase.getText());
				a=0;
				if(Rrectangulo.isSelected())
					a=h*b;
				if(Rtriangulo.isSelected())
					a=h*b/2;
				
				this.Tarea.setText(String.valueOf(a));				
			}
		}
		else 
			if(e.getSource()==this.Bperimetro) {
				if(Novacios(this.Taltura,this.Tbase))
				{
					double h,b,p;
					h=Double.parseDouble(this.Taltura.getText());
					b=Double.parseDouble(this.Tbase.getText());
					p=0;
					if(Rrectangulo.isSelected())
					 p=h*2+b*2;
					if(Rtriangulo.isSelected())
						p=Math.sqrt(h*h+b*b);
					
					this.Tarea.setText(String.valueOf(p));
	;				
				}
			}
			
		else
			if(e.getSource()==this.Bsalir)
				this.dispose();
		
	}

}