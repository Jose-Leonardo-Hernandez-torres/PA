package Unidad_1;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.FlowLayout;
import java.awt.BorderLayout;
import javax.swing.BoxLayout;
import java.awt.GridLayout;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;

public class Programa02_a2233336147_d extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField TEvaluacion;
	private JTextField Tnumero;
	private JButton Bevaluar,BSalir;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Programa02_a2233336147_d frame = new Programa02_a2233336147_d();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Programa02_a2233336147_d() {
		setTitle("Programa 02 a2233336147");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[]{96, 96, 96, 96, 96, 96, 0};
		gbl_contentPane.rowHeights = new int[]{0, 50, 0, 0};
		gbl_contentPane.columnWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		gbl_contentPane.rowWeights = new double[]{0.0, 0.0, 0.0, Double.MIN_VALUE};
		contentPane.setLayout(gbl_contentPane);
		
		JLabel lblNewLabel = new JLabel("introduce el numero");
		GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
		gbc_lblNewLabel.fill = GridBagConstraints.BOTH;
		gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel.gridx = 0;
		gbc_lblNewLabel.gridy = 0;
		contentPane.add(lblNewLabel, gbc_lblNewLabel);
		
		Bevaluar = new JButton("Evaluar");
		Bevaluar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if ((!Tnumero.getText().isEmpty())&&(!Tnumero.getText().isBlank()))
				{
					double num = Double.parseDouble(Tnumero.getText());
					if(num>0)
						TEvaluacion.setText("positivo");
					else
						if(num<0)
							TEvaluacion.setText("negativo");
						else
							TEvaluacion.setText("cero");
				}
			}
		});
		
		TEvaluacion = new JTextField();
		GridBagConstraints gbc_tEvaluacion = new GridBagConstraints();
		gbc_tEvaluacion.fill = GridBagConstraints.BOTH;
		gbc_tEvaluacion.insets = new Insets(0, 0, 5, 5);
		gbc_tEvaluacion.gridx = 2;
		gbc_tEvaluacion.gridy = 0;
		contentPane.add(TEvaluacion, gbc_tEvaluacion);
		TEvaluacion.setColumns(10);
		GridBagConstraints gbc_bevaluar = new GridBagConstraints();
		gbc_bevaluar.fill = GridBagConstraints.BOTH;
		gbc_bevaluar.insets = new Insets(0, 0, 5, 5);
		gbc_bevaluar.gridx = 4;
		gbc_bevaluar.gridy = 0;
		contentPane.add(Bevaluar, gbc_bevaluar);
		
		JLabel lblNewLabel_1 = new JLabel("evaluacion");
		GridBagConstraints gbc_lblNewLabel_1 = new GridBagConstraints();
		gbc_lblNewLabel_1.fill = GridBagConstraints.BOTH;
		gbc_lblNewLabel_1.insets = new Insets(0, 0, 0, 5);
		gbc_lblNewLabel_1.gridx = 0;
		gbc_lblNewLabel_1.gridy = 2;
		contentPane.add(lblNewLabel_1, gbc_lblNewLabel_1);
		
		BSalir = new JButton("Salir");
		BSalir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Programa02_a2233336147_d.this.dispose();
			}
		});
		
		Tnumero = new JTextField();
		GridBagConstraints gbc_tnumero = new GridBagConstraints();
		gbc_tnumero.anchor = GridBagConstraints.EAST;
		gbc_tnumero.insets = new Insets(0, 0, 0, 5);
		gbc_tnumero.fill = GridBagConstraints.VERTICAL;
		gbc_tnumero.gridx = 2;
		gbc_tnumero.gridy = 2;
		contentPane.add(Tnumero, gbc_tnumero);
		Tnumero.setColumns(10);
		GridBagConstraints gbc_bSalir = new GridBagConstraints();
		gbc_bSalir.insets = new Insets(0, 0, 0, 5);
		gbc_bSalir.fill = GridBagConstraints.BOTH;
		gbc_bSalir.gridx = 4;
		gbc_bSalir.gridy = 2;
		contentPane.add(BSalir, gbc_bSalir);
	}

}
