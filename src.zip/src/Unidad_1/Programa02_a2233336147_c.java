package Unidad_1;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.FlowLayout;
import java.awt.BorderLayout;
import javax.swing.BoxLayout;

public class Programa02_a2233336147_c extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField TEvaluacion;
	private JTextField Tnumero;
	private JButton Bevaluar,BSalir;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Programa02_a2233336147_c frame = new Programa02_a2233336147_c();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Programa02_a2233336147_c() {
		setTitle("Programa 02 a2233336147");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.X_AXIS));
		
		JLabel lblNewLabel = new JLabel("introduce el numero");
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("evaluacion");
		contentPane.add(lblNewLabel_1);
		
		Bevaluar = new JButton("Evaluar");
		Bevaluar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if ((!Tnumero.getText().isEmpty())&&(!Tnumero.getText().isBlank()))
				{
					double num = Double.parseDouble(Tnumero.getText());
					if(num>0)
						TEvaluacion.setText("positivo");
					else
						if(num<0)
							TEvaluacion.setText("negativo");
						else
							TEvaluacion.setText("cero");
				}
			}
		});
		contentPane.add(Bevaluar);
		
		BSalir = new JButton("Salir");
		BSalir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Programa02_a2233336147_c.this.dispose();
			}
		});
		contentPane.add(BSalir);
		
		TEvaluacion = new JTextField();
		contentPane.add(TEvaluacion);
		TEvaluacion.setColumns(10);
		
		Tnumero = new JTextField();
		contentPane.add(Tnumero);
		Tnumero.setColumns(10);
	}

}
