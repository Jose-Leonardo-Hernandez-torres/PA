package Unidad_1;

import java.awt.EventQueue;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class Layouts_1_a extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		Marco_Layout marco = new Marco_Layout();
		marco.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		marco.setVisible(true);
	}
	
}

class Marco_Layout extends JFrame{
	
	
	public Marco_Layout() {
		setTitle("pueba acciones");
		
		setBounds(600,350,600,300);
		
		Panel_Layout lamina = new Panel_Layout();
		add(lamina);
	}
	
}
class Panel_Layout extends JFrame{
	
	public Panel_Layout() {
		add(new JButton("Amarillo"));
		add(new JButton("Rojo"));
		add(new JButton("Azul"));
	}
}







