package Unidad_1;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Controlador6d implements ActionListener {

	Programa06_d ventana;
	
	public void Controlador6d(String titulo)  {
		
		
		ventana=new Programa06_d();
		ventana.BciudadI.addActionListener(this);
		ventana.Bciudadm.addActionListener(this);
		ventana.Bsalir.addActionListener(this);
		this.ventana.setTitle(titulo);
		this.ventana.setVisible(true);
		this.ventana.Cciudades.setSelectedIndex(0);
		this.ventana.Lcuidades.setSelectedIndex(0);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(this.ventana.BciudadI==e.getSource()) {
			
			int pos=this.ventana.Lcuidades.getSelectedIndex();
			JOptionPane.showMessageDialog(this.ventana,this.ventana.lista.getElementAt(pos).toString());	
		}
		else
			if(this.ventana.Bciudadm==e.getSource()) {
				
				JOptionPane.showMessageDialog(this.ventana,this.ventana.Cciudades.getSelectedItem().toString());
			}
			else
				if(this.ventana.Bsalir==e.getSource()) {
					this.ventana.dispose();
				}
			
			
		
		
	}
	
}
