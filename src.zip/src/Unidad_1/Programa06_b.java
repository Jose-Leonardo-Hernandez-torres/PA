package Unidad_1;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.GridLayout;
import java.awt.GridBagLayout;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.JList;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;

public class Programa06_b extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel PanelPrincipal;
	JList Lciudades;
	JComboBox Cciudadesm;
	String[] ciudadesm= {"Tampico","Cd. Mexico","Monterrey","Guadalajara","Acapulco"};
	String [] ciudadesi={"Tampico","Cd. Mexico","Monterrey","Guadalajara","New York"};
	DefaultListModel lista;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Programa06_b frame = new Programa06_b();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	
	
	public void inicializar () {
		for(String ciudad: this.ciudadesm)
			this.Cciudadesm.addItem(ciudad);
		this.lista = new DefaultListModel();
		
		for(String ciudad:this.ciudadesi)
			this.lista.addElement(ciudad);
		
		this.Lciudades.setModel(this.lista);
	}
	
	
	
	public Programa06_b() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		PanelPrincipal = new JPanel();
		PanelPrincipal.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(PanelPrincipal);
		GridBagLayout gbl_panelPrincipal = new GridBagLayout();
		gbl_panelPrincipal.columnWidths = new int[]{0, 0};
		gbl_panelPrincipal.rowHeights = new int[]{0, 57, 64, 61, 0, 65, 0};
		gbl_panelPrincipal.columnWeights = new double[]{1.0, Double.MIN_VALUE};
		gbl_panelPrincipal.rowWeights = new double[]{0.0, 1.0, 1.0, 1.0, 0.0, 0.0, Double.MIN_VALUE};
		PanelPrincipal.setLayout(gbl_panelPrincipal);
		
		JPanel PanelCiudadm = new JPanel();
		GridBagConstraints gbc_PanelCiudadm = new GridBagConstraints();
		gbc_PanelCiudadm.insets = new Insets(0, 0, 5, 0);
		gbc_PanelCiudadm.fill = GridBagConstraints.BOTH;
		gbc_PanelCiudadm.gridx = 0;
		gbc_PanelCiudadm.gridy = 1;
		PanelPrincipal.add(PanelCiudadm, gbc_PanelCiudadm);
		GridBagLayout gbl_PanelCiudadm = new GridBagLayout();
		gbl_PanelCiudadm.columnWidths = new int[]{0, 0, 0, 0};
		gbl_PanelCiudadm.rowHeights = new int[]{0, 0};
		gbl_PanelCiudadm.columnWeights = new double[]{0.0, 0.0, 1.0, Double.MIN_VALUE};
		gbl_PanelCiudadm.rowWeights = new double[]{0.0, Double.MIN_VALUE};
		PanelCiudadm.setLayout(gbl_PanelCiudadm);
		
		JLabel lblNewLabel = new JLabel("Ciudades de Mexico");
		GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
		gbc_lblNewLabel.insets = new Insets(0, 0, 0, 5);
		gbc_lblNewLabel.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel.gridx = 1;
		gbc_lblNewLabel.gridy = 0;
		PanelCiudadm.add(lblNewLabel, gbc_lblNewLabel);
		
		Cciudadesm = new JComboBox();
		GridBagConstraints gbc_Cciudadesm = new GridBagConstraints();
		gbc_Cciudadesm.fill = GridBagConstraints.HORIZONTAL;
		gbc_Cciudadesm.gridx = 2;
		gbc_Cciudadesm.gridy = 0;
		PanelCiudadm.add(Cciudadesm, gbc_Cciudadesm);
		
		
		JPanel PanelCiudadesI = new JPanel();
		GridBagConstraints gbc_PanelCiudadesI = new GridBagConstraints();
		gbc_PanelCiudadesI.insets = new Insets(0, 0, 5, 0);
		gbc_PanelCiudadesI.fill = GridBagConstraints.BOTH;
		gbc_PanelCiudadesI.gridx = 0;
		gbc_PanelCiudadesI.gridy = 2;
		PanelPrincipal.add(PanelCiudadesI, gbc_PanelCiudadesI);
		GridBagLayout gbl_PanelCiudadesI = new GridBagLayout();
		gbl_PanelCiudadesI.columnWidths = new int[]{0, 0, 0, 0};
		gbl_PanelCiudadesI.rowHeights = new int[]{0, 0};
		gbl_PanelCiudadesI.columnWeights = new double[]{0.0, 0.0, 1.0, Double.MIN_VALUE};
		gbl_PanelCiudadesI.rowWeights = new double[]{1.0, Double.MIN_VALUE};
		PanelCiudadesI.setLayout(gbl_PanelCiudadesI);
		
		JLabel lblNewLabel_1 = new JLabel("Ciudades Importantes");
		GridBagConstraints gbc_lblNewLabel_1 = new GridBagConstraints();
		gbc_lblNewLabel_1.insets = new Insets(0, 0, 0, 5);
		gbc_lblNewLabel_1.gridx = 1;
		gbc_lblNewLabel_1.gridy = 0;
		PanelCiudadesI.add(lblNewLabel_1, gbc_lblNewLabel_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		GridBagConstraints gbc_scrollPane = new GridBagConstraints();
		gbc_scrollPane.fill = GridBagConstraints.BOTH;
		gbc_scrollPane.gridx = 2;
		gbc_scrollPane.gridy = 0;
		PanelCiudadesI.add(scrollPane, gbc_scrollPane);
		
	      Lciudades = new JList();
		scrollPane.setViewportView(Lciudades);
		
		
		
		JPanel PanelBotones = new JPanel();
		GridBagConstraints gbc_PanelBotones = new GridBagConstraints();
		gbc_PanelBotones.insets = new Insets(0, 0, 5, 0);
		gbc_PanelBotones.fill = GridBagConstraints.BOTH;
		gbc_PanelBotones.gridx = 0;
		gbc_PanelBotones.gridy = 3;
		PanelPrincipal.add(PanelBotones, gbc_PanelBotones);
		GridBagLayout gbl_PanelBotones = new GridBagLayout();
		gbl_PanelBotones.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0};
		gbl_PanelBotones.rowHeights = new int[]{0, 0};
		gbl_PanelBotones.columnWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		gbl_PanelBotones.rowWeights = new double[]{0.0, Double.MIN_VALUE};
		PanelBotones.setLayout(gbl_PanelBotones);
		
		JButton Bciudadm = new JButton("Ciudades Mexicanas");
		GridBagConstraints gbc_Bciudadm = new GridBagConstraints();
		gbc_Bciudadm.insets = new Insets(0, 0, 0, 5);
		gbc_Bciudadm.gridx = 1;
		gbc_Bciudadm.gridy = 0;
		PanelBotones.add(Bciudadm, gbc_Bciudadm);
		
		JButton Bciudadi = new JButton("Ciudades Internacionales");
		GridBagConstraints gbc_Bciudadi = new GridBagConstraints();
		gbc_Bciudadi.insets = new Insets(0, 0, 0, 5);
		gbc_Bciudadi.gridx = 3;
		gbc_Bciudadi.gridy = 0;
		PanelBotones.add(Bciudadi, gbc_Bciudadi);
		
		JButton Bsalir = new JButton("Salir");
		GridBagConstraints gbc_Bsalir = new GridBagConstraints();
		gbc_Bsalir.gridx = 5;
		gbc_Bsalir.gridy = 0;
		PanelBotones.add(Bsalir, gbc_Bsalir);
		this.inicializar();
	}

}