package Unidad_1;
import Unidad_1_Controlador.Programa07_c_controlador;

public class Programa07_b_ejecutor {
	
	
	
	public static void main(String[] args) {
		Programa07_c_controlador padre = new Programa07_c_controlador();
	}

}
