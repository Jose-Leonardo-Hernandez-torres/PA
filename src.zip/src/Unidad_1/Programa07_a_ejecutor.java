package Unidad_1;

import Unidad_1_Controlador.Controlador;

public class Programa07_a_ejecutor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Controlador padre = new Controlador();
	}

}
