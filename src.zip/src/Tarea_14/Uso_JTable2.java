package Tarea_14;
import javax.swing.*;
import javax.swing.table.AbstractTableModel;
import java.awt.*;

public class Uso_JTable2 extends JFrame {

    public Uso_JTable2() {
        super("Tabla Personalizada");

        MiTablaModelo modelo = new MiTablaModelo();

        JTable tabla = new JTable(modelo);

        JScrollPane scrollPane = new JScrollPane(tabla);

        add(scrollPane, BorderLayout.CENTER);

        pack();

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setVisible(true);
    }

    public static class MiTablaModelo extends AbstractTableModel {

        private final String[] columnas = {"Columna 0", "Columna 1", "Columna 2"};
        private final Object[][] datos = {
            {1, 13, 14},
            {22, 23, 24},
            {32, 33, 34},
            {42, 43, 44},
            {52, 53, 54},
        };

        @Override
        public int getRowCount() {
            return datos.length;
        }

        @Override
        public int getColumnCount() {
            return columnas.length;
        }

        @Override
        public Object getValueAt(int row, int column) {
            Object valor = datos[row][column];
            return agregarEspacios(valor);
        }

        private String agregarEspacios(Object valor) {
            String valorStr = valor.toString();
            return String.join(" ", valorStr.split(""));
        }

        @Override
        public String getColumnName(int column) {
            return columnas[column];
        }

        @Override
        public boolean isCellEditable(int rowIndex, int columnIndex) {
            return false; 
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Uso_JTable2());
    }
}
