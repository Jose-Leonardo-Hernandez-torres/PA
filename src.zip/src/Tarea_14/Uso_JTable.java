package Tarea_14;
import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.print.PrinterException;

public class Uso_JTable extends JFrame {

    private JTable tablaPlanetas;

    public Uso_JTable() {
        Object[][] datosPlanetas = {
            {"Mercurio", 2440.0, 0, false},
            {"Venus", 6052.0, 0, false},
            {"Tierra", 6378.0, 1, false},
            {"Marte", 3397.0, 2, false},
            {"Júpiter", 71492.0, 16, true},
            {"Saturno", 60268.0, 18, true},
            {"Urano", 25559.0, 17, true},
            {"Neptuno", 24766.0, 8, true}
        };

        String[] columnas = {"Nombre", "Radio", "Lunas", "Gaseoso"};

        DefaultTableModel modeloTabla = new DefaultTableModel(datosPlanetas, columnas);

        tablaPlanetas = new JTable(modeloTabla);

        tablaPlanetas.getColumnModel().getColumn(0).setPreferredWidth(100); 
        tablaPlanetas.getColumnModel().getColumn(1).setPreferredWidth(70);  
        tablaPlanetas.getColumnModel().getColumn(2).setPreferredWidth(50);  
        tablaPlanetas.getColumnModel().getColumn(3).setPreferredWidth(70);  

        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);
        tablaPlanetas.getColumnModel().getColumn(1).setCellRenderer(centerRenderer);
        tablaPlanetas.getColumnModel().getColumn(2).setCellRenderer(centerRenderer);
        tablaPlanetas.getColumnModel().getColumn(3).setCellRenderer(centerRenderer);

        tablaPlanetas.setRowHeight(25);

        JScrollPane scrollPane = new JScrollPane(tablaPlanetas);

        JPanel panelBoton = new JPanel();
        JButton botonImprimir = new JButton("Imprimir Tabla");
        botonImprimir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    tablaPlanetas.print(JTable.PrintMode.FIT_WIDTH);
                } catch (PrinterException ex) {
                    ex.printStackTrace();
                }
            }
        });
        panelBoton.add(botonImprimir);

        this.setLayout(new BorderLayout());
        this.add(scrollPane, BorderLayout.CENTER);
        this.add(panelBoton, BorderLayout.SOUTH); 

        this.setTitle("Los planetas");
        this.setSize(400, 300);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Uso_JTable ventana = new Uso_JTable();
            ventana.setVisible(true);
        });
    }
}
