package Tarea_14;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;

public class TablaProductos extends JFrame {

    public TablaProductos() {
        setTitle("Productos");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); 
        
        String[] opciones = {"productos", "pruebas"};
        JComboBox<String> comboBox = new JComboBox<>(opciones);
        
        JPanel centralPanel = new JPanel();
        centralPanel.setLayout(new BorderLayout()); 
        
        String[] columnNames = {"Código", "Nombre", "Sección", "Precio", "Fecha", "Importado", "País de Origen", "Foto"};
        Object[][] data = {};
        
        DefaultTableModel model = new DefaultTableModel(data, columnNames);
        JTable table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);
        
        Object[][] productos = {
            {"001", "Laptop", "Electrónica", "$800", "2024-09-15", "Sí", "China", null},
            {"002", "Teclado", "Periféricos", "$50", "2024-09-14", "No", "EE.UU.", null},
            {"003", "Ratón", "Periféricos", "$30", "2024-09-13", "Sí", "Taiwán", null},
            {"004", "Monitor", "Electrónica", "$200", "2024-09-12", "No", "Corea del Sur", null},
            {"005", "Audífonos", "Accesorios", "$100", "2024-09-11", "Sí", "Japón", null},
            {"006", "USB", "Accesorios", "$15", "2024-09-10", "No", "Alemania", null},
            {"007", "SSD", "Almacenamiento", "$150", "2024-09-09", "Sí", "China", null},
            {"008", "Micrófono", "Accesorios", "$70", "2024-09-08", "Sí", "EE.UU.", null},
            {"009", "Cargador Tipo C", "Accesorios", "$25", "2024-09-07", "No", "Hong Kong", null},
            {"010", "Aire Comprimido", "Accesorios", "$20", "2024-09-06", "Sí", "Francia", null},
            {"011", "Fuente de alimentación", "Electrónica", "$60", "2024-09-05", "No", "China", null},
            {"012", "Disco Duro", "Almacenamiento", "$120", "2024-09-04", "Sí", "Japón", null}
        };
        
        for (Object[] producto : productos) {
            model.addRow(producto);
        }
        
        JPanel topPanel = new JPanel();
        topPanel.add(comboBox);
        centralPanel.add(topPanel, BorderLayout.NORTH);
        centralPanel.add(scrollPane, BorderLayout.CENTER);
        
        add(centralPanel);
        
        comboBox.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String seleccion = (String) comboBox.getSelectedItem();
                
                if (seleccion.equals("productos")) {
                } else if (seleccion.equals("pruebas")) {
                    System.out.println("Pruebas seleccionada. No se realiza ninguna acción.");
                }
            }
        });
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            TablaProductos frame = new TablaProductos();
            frame.setVisible(true);
        });
    }
}
