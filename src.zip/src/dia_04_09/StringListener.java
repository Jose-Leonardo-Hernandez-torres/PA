package dia_04_09;

public interface StringListener { 
public void textEmitted(String text);
}
