package ejercicio_unidad1;
import javax.swing.*;
import java.awt.GridLayout;
import java.awt.event.*;
import java.io.*;
import java.util.prefs.Preferences;

public class FormularioControlador {
    private FormularioVista vista;
    private Preferences preferencias;

    public FormularioControlador(FormularioVista vista) {
        this.vista = vista;
        this.preferencias = Preferences.userNodeForPackage(FormularioControlador.class);
        agregarEventos();
    }
    private void agregarEventos() {
        vista.getBotonOk().addActionListener(e -> agregarDatosATabla());
        vista.getBotonHola().addActionListener(e -> JOptionPane.showMessageDialog(vista, "¡Hola!"));
        vista.getBotonAdios().addActionListener(e -> JOptionPane.showMessageDialog(vista, "¡Adiós!"));
        vista.getItemMenuImportar().addActionListener(e -> importarDatos());
        vista.getItemMenuExportar().addActionListener(e -> exportarDatos());
        vista.getItemMenuSalir().addActionListener(e -> System.exit(0));
        vista.getItemMenuOcultarVentana().addActionListener(e -> vista.setVisible(false));
        vista.getItemMenuPreferencias().addActionListener(e -> mostrarDialogoPreferencias());
    }
    private void agregarDatosATabla() {
        String nombre = vista.getCampoNombre().getText();
        String ocupacion = vista.getCampoOcupacion().getText();
        String edad = (String) vista.getComboEdad().getSelectedItem();
        String empleo = (String) vista.getComboEmpleo().getSelectedItem();
        boolean ciudadano = vista.getCheckCiudadano().isSelected();
        String idTributario = vista.getCampoIdTributario().getText();
        String genero = vista.getRadioMasculino().isSelected() ? "masculino" : "femenino";
        Object[] fila = {vista.getModeloTabla().getRowCount() + 1, nombre, ocupacion, edad, empleo, ciudadano, idTributario, genero};
        vista.getModeloTabla().addRow(fila);
        limpiarCampos();
    }
    private void limpiarCampos() {
        vista.getCampoNombre().setText("");
        vista.getCampoOcupacion().setText("");
        vista.getComboEdad().setSelectedIndex(0);
        vista.getComboEmpleo().setSelectedIndex(0);
        vista.getCheckCiudadano().setSelected(false);
        vista.getCampoIdTributario().setText("");
        vista.getRadioMasculino().setSelected(false);
        vista.getRadioFemenino().setSelected(false);
    }

    private void importarDatos() {
        JFileChooser fileChooser = new JFileChooser();
        int seleccion = fileChooser.showOpenDialog(vista);
        if (seleccion == JFileChooser.APPROVE_OPTION) {
            File archivo = fileChooser.getSelectedFile();
            try (BufferedReader reader = new BufferedReader(new FileReader(archivo))) {
                String linea;
                while ((linea = reader.readLine()) != null) {
                    String[] datos = linea.split(",");
                    vista.getModeloTabla().addRow(datos);
                }
            } catch (IOException e) {
                JOptionPane.showMessageDialog(vista, "Error al importar el archivo: " + e.getMessage());
            }
        }
    }
    private void exportarDatos() {
        JFileChooser fileChooser = new JFileChooser();
        int seleccion = fileChooser.showSaveDialog(vista);
        if (seleccion == JFileChooser.APPROVE_OPTION) {
            File archivo = fileChooser.getSelectedFile();
            try (PrintWriter writer = new PrintWriter(new FileWriter(archivo))) {
                for (int i = 0; i < vista.getModeloTabla().getRowCount(); i++) {
                    for (int j = 0; j < vista.getModeloTabla().getColumnCount(); j++) {
                        writer.print(vista.getModeloTabla().getValueAt(i, j) + ",");
                    }
                    writer.println();
                }
            } catch (IOException e) {
                JOptionPane.showMessageDialog(vista, "Error al exportar el archivo: " + e.getMessage());
            }
        }
    }

    private void mostrarDialogoPreferencias() {
        JDialog dialogo = new JDialog(vista, "Preferencias", true);
        dialogo.setSize(300, 200);
        dialogo.setLayout(new GridLayout(4, 2));
        JTextField campoUsuario = new JTextField(preferencias.get("usuario", ""));
        JPasswordField campoContrasena = new JPasswordField(preferencias.get("contrasena", ""));
        JTextField campoPuerto = new JTextField(String.valueOf(preferencias.getInt("puerto", 3306)));
        dialogo.add(new JLabel("Usuario:"));
        dialogo.add(campoUsuario);
        dialogo.add(new JLabel("Contraseña:"));
        dialogo.add(campoContrasena);
        dialogo.add(new JLabel("Puerto:"));
        dialogo.add(campoPuerto);
        JButton botonOk = new JButton("Aceptar");
        botonOk.addActionListener(e -> {
            preferencias.put("usuario", campoUsuario.getText());
            preferencias.put("contrasena", new String(campoContrasena.getPassword()));
            preferencias.putInt("puerto", Integer.parseInt(campoPuerto.getText()));
            dialogo.dispose();
        });
        JButton botonCancelar = new JButton("Cancelar");
        botonCancelar.addActionListener(e -> dialogo.dispose());
        dialogo.add(botonOk);
        dialogo.add(botonCancelar);
        dialogo.setVisible(true);
    }
}