package ejercicio_unidad1;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.prefs.Preferences;
public class FormularioVista extends JFrame {

    private JPanel panelFormulario;
    private JTextField campoNombre, campoOcupacion, campoIdTributario;
    private JComboBox<String> comboEdad, comboEmpleo;
    private JCheckBox checkCiudadano;
    private JRadioButton radioMasculino, radioFemenino;
    private JButton botonOk, botonHola, botonAdios;
    private DefaultTableModel modeloTabla;
    private JTable tablaDatos;
    
    private JMenuItem itemMenuImportar, itemMenuExportar, itemMenuSalir, itemMenuOcultarVentana, itemMenuPreferencias;

    public FormularioVista() {
        setTitle("Hola Mundo");
        setSize(800, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JMenuBar barraMenu = new JMenuBar();
        JMenu menuArchivo = new JMenu("Archivo");
        JMenu menuVentana = new JMenu("Ventana");

        itemMenuImportar = new JMenuItem("Importar datos");
        itemMenuExportar = new JMenuItem("Exportar datos");
        itemMenuSalir = new JMenuItem("Salir");
        menuArchivo.add(itemMenuImportar);
        menuArchivo.add(itemMenuExportar);
        menuArchivo.addSeparator();
        menuArchivo.add(itemMenuSalir);
        itemMenuOcultarVentana = new JMenuItem("Ocultar ventana");
        itemMenuPreferencias = new JMenuItem("Preferencias");
        menuVentana.add(itemMenuOcultarVentana);
        menuVentana.add(itemMenuPreferencias);
        barraMenu.add(menuArchivo);
        barraMenu.add(menuVentana);
        setJMenuBar(barraMenu);

        JPanel panelSuperior = new JPanel();
        botonHola = new JButton("Hola");
        botonAdios = new JButton("Adiós");
        panelSuperior.add(botonHola);
        panelSuperior.add(botonAdios);
        add(panelSuperior, BorderLayout.NORTH);
        panelFormulario = new JPanel(new GridLayout(9, 2, 5, 5));
        panelFormulario.add(new JLabel("Nombre:"));
        campoNombre = new JTextField();
        panelFormulario.add(campoNombre);

        panelFormulario.add(new JLabel("Ocupación:"));
        campoOcupacion = new JTextField();
        panelFormulario.add(campoOcupacion);

        panelFormulario.add(new JLabel("Edad:"));
        String[] opcionesEdad = {"Menor de 18", "18 a 65", "65 o más"};
        comboEdad = new JComboBox<>(opcionesEdad);
        panelFormulario.add(comboEdad);

        panelFormulario.add(new JLabel("Empleo:"));
        String[] opcionesEmpleo = {"empleado", "desempleado"};
        comboEmpleo = new JComboBox<>(opcionesEmpleo);
        panelFormulario.add(comboEmpleo);

        panelFormulario.add(new JLabel("Ciudadano de EE.UU.:"));
        checkCiudadano = new JCheckBox();
        panelFormulario.add(checkCiudadano);

        panelFormulario.add(new JLabel("ID Tributario:"));
        campoIdTributario = new JTextField();
        panelFormulario.add(campoIdTributario);
        panelFormulario.add(new JLabel("Género:"));
        JPanel panelGenero = new JPanel(new FlowLayout(FlowLayout.LEFT));
        radioMasculino = new JRadioButton("masculino");
        radioFemenino = new JRadioButton("femenino");
        ButtonGroup grupoGenero = new ButtonGroup();
        grupoGenero.add(radioMasculino);
        grupoGenero.add(radioFemenino);
        panelGenero.add(radioMasculino);
        panelGenero.add(radioFemenino);
        panelFormulario.add(panelGenero);
        botonOk = new JButton("Aceptar");
        panelFormulario.add(botonOk);
        panelFormulario.add(new JLabel());
        add(panelFormulario, BorderLayout.WEST);
        String[] columnas = {"ID", "Nombre", "Ocupación", "Edad", "Empleo", "Ciudadano EE.UU.", "ID Tributario", "Género"};
        modeloTabla = new DefaultTableModel(columnas, 0);
        tablaDatos = new JTable(modeloTabla);
        JScrollPane scrollPane = new JScrollPane(tablaDatos);
        add(scrollPane, BorderLayout.CENTER);
    }
    public JTextField getCampoNombre() { return campoNombre; }
    public JTextField getCampoOcupacion() { return campoOcupacion; }
    public JTextField getCampoIdTributario() { return campoIdTributario; }
    public JComboBox<String> getComboEdad() { return comboEdad; }
    public JComboBox<String> getComboEmpleo() { return comboEmpleo; }
    public JCheckBox getCheckCiudadano() { return checkCiudadano; }
    public JRadioButton getRadioMasculino() { return radioMasculino; }
    public JRadioButton getRadioFemenino() { return radioFemenino; }
    public JButton getBotonOk() { return botonOk; }
    public JButton getBotonHola() { return botonHola; }
    public JButton getBotonAdios() { return botonAdios; }
    public DefaultTableModel getModeloTabla() { return modeloTabla; }
    public JMenuItem getItemMenuImportar() { return itemMenuImportar; }
    public JMenuItem getItemMenuExportar() { return itemMenuExportar; }
    public JMenuItem getItemMenuSalir() { return itemMenuSalir; }
    public JMenuItem getItemMenuOcultarVentana() { return itemMenuOcultarVentana; }
    public JMenuItem getItemMenuPreferencias() { return itemMenuPreferencias; }
}