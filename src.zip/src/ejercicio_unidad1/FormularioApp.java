package ejercicio_unidad1;

import javax.swing.*;
public class FormularioApp {
    public static void main(String[] args) {
    	
        FormularioVista vista = new FormularioVista();
        FormularioControlador controlador = new FormularioControlador(vista);
        vista.setVisible(true);
        
    }
}