package Unidad_1_Vista;

import java.awt.CardLayout;
import java.awt.EventQueue;

import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JInternalFrame.JDesktopIcon;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;

public class Programa07_b_vista extends JFrame {

	private static final long serialVersionUID = 1L;

	private JPanel Principal;
	public JMenuBar BarraPrincipal;
	public JDesktopPane Descritorio;
	public JMenu Mprincipal, Malmacen, Mconfiguracion,Msalida;
	public JMenuItem MOventas, MOreporteventas, MOinventarios,MOreporteinventarios,MOproductos,MOcategorias,MOusuarios,MOsalida;
	
	public Programa07_b_vista() {
		setTitle("a2233336147");
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		
		BarraPrincipal = new JMenuBar();
		setJMenuBar(BarraPrincipal);
		
		Mprincipal = new JMenu("Principal");
		BarraPrincipal.add(Mprincipal);
		
		MOventas = new JMenuItem("Ventas");
		Mprincipal.add(MOventas);
		
		MOreporteventas = new JMenuItem("Reporte Ventas");
		Mprincipal.add(MOreporteventas);
		
		Malmacen = new JMenu("Almacen");
		BarraPrincipal.add(Malmacen);
		
		MOinventarios = new JMenuItem("Inventarios");
		Malmacen.add(MOinventarios);
		
		MOreporteinventarios = new JMenuItem("Reporte Inventario");
		Malmacen.add(MOreporteinventarios);
		
		Mconfiguracion = new JMenu("Configuracion");
		BarraPrincipal.add(Mconfiguracion);
		
		MOproductos = new JMenuItem("Productos");
		Mconfiguracion.add(MOproductos);
		
		MOcategorias = new JMenuItem("Categorias");
		Mconfiguracion.add(MOcategorias);
		
	    MOusuarios = new JMenuItem("Usuarios");
		Mconfiguracion.add(MOusuarios);
		
		Msalida = new JMenu("Salida");
		BarraPrincipal.add(Msalida);
		
		MOsalida = new JMenuItem("Salir");
		Msalida.add(MOsalida);
		
		Principal = new JPanel();
		Principal.setBorder(new EmptyBorder(5,5,5,5));
		setContentPane(Principal);
		Principal.setLayout(new CardLayout(0,0));
		
		Descritorio = new JDesktopPane();
		Principal.add(Descritorio);
		Descritorio.setLayout(new CardLayout(0,0));
		this.BarraPrincipal.setEnabled(false);
	}
	
}
