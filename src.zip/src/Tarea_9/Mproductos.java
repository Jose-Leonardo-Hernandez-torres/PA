package Tarea_9;

import javax.swing.JOptionPane;
public class Mproductos {
	private Lproductos listaproductos;
	 private Carchivo archivotxt;
	 private Boolean valido;
	 public Mproductos()		
	 { valido=true;
	 archivotxt =new Carchivo("productos.txt");
	 if (archivotxt.Existe())
	 listaproductos = new Lproductos(archivotxt.CargarArchivo());
	 else
	 {
	 listaproductos = new Lproductos();
	 JOptionPane.showMessageDialog(null, "No encontro el archivo"+archivotxt.getNombrearchivo());
	 valido=false;
	 }
	 }
	 public void capturar()
	 { String codigo,producto,precio;
	 String info=listaproductos.mostrarLista();
	 codigo=Libreria.leer(info+"\nIntroduce el codigo del producto");
	 producto=Libreria.leer(info+"\nIntroduce el nombre producto");
	 precio=Libreria.leer(info+"\nIntroduce el precio del producto", 2);
	 if ((codigo!=null)&&(producto!=null)&&(precio!=null))
	 if( (!codigo.isEmpty())&&(!producto.isEmpty())&&(!precio.isEmpty()))
	 {
	 Cproducto nodo= new Cproducto(codigo,producto,precio);
	 if (!listaproductos.insertar(nodo))
	 JOptionPane.showMessageDialog(null, "el codigo ya existe no se puede agregar");
	 }
	 }
	
	 public void eliminar()
	 { String codigo,producto,precio;
	 int posicion;
	 String info=listaproductos.mostrarLista();
	 codigo=Libreria.leer(info+"\nIntroduce el codigo del producto");
	 posicion=listaproductos.existe(codigo);
	 System.out.println("posicion "+posicion);
	 if (posicion>-1)
	 listaproductos.eliminar(posicion);
	 else
	 JOptionPane.showMessageDialog(null, "no existe el codigo");
	
	 }
	
	 public void modificar()
	 { String codigo,producto,precio;
	 int posicion;
	 String info=listaproductos.mostrarLista();
	 codigo=Libreria.leer(info+"\nIntroduce el codigo del producto a modificar");
	 posicion=listaproductos.existe(codigo);
	
	 System.out.println("posicion "+posicion);
	 if (posicion>-1)
	 {
	
	 precio=Libreria.leer(info+"\nIntroduce el precio del producto", 2);
	 posicion=listaproductos.existe(codigo);
	 
	  listaproductos.modificar(posicion, precio);
	  }
	  else
	  JOptionPane.showMessageDialog(null, "no existe el codigo");
	 
	  }
	 
	 
	  public void Listado()
	  {
	 
	  if (valido)
	  JOptionPane.showMessageDialog(null, listaproductos.mostrarLista());
	  else
	  JOptionPane.showMessageDialog(null, "no hay datos");
	  }
	 
	  public void EjecutarMproductos()
	  {
	  String[] datosmenu= {"Menu de Productos","1.-Altas ","2.-Bajas ","3.-Modificar ","5.-Listado ","6.-Salida "};
	  String opcion = Libreria.leer(Libreria.mostrarmenu(datosmenu), 1);
	  if (opcion==null)
	  JOptionPane.showMessageDialog(null, "dato incorrecto introducido");
	  else
	  switch (opcion)
	  {
	  case "1":this.capturar();break;
	  case "2":this.eliminar();;break;
	  case "3":this.modificar();break;
	  case "5":this.Listado();break;
	  }
	  archivotxt.GuardarArchivo(listaproductos.guardar());
	  System.out.println(listaproductos.mostrarLista());
	  } 

}