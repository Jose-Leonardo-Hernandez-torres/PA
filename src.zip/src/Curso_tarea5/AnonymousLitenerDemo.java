package Curso_tarea5;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class AnonymousLitenerDemo extends JFrame {
public AnonymousLitenerDemo () {
	JButton jbtNew = new JButton("New"); 
	JButton jbtOpen = new JButton("Open"); 
	JButton jbtSave = new JButton("Save"); 
	JButton jbtPrint = new JButton("Print");
	
	JPanel panel = new JPanel();

	panel.add(jbtNew);
	panel.add(jbtOpen);
	panel.add(jbtSave);
	panel.add(jbtPrint);

	add (panel);
	
	jbtNew.addActionListener(new ActionListener() {

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			System.out.println("Process New");
		}
	}
);
	
	jbtOpen.addActionListener(new ActionListener() {

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			System.out.println("Process Open");
		}
	}
);
	
	
	
	jbtSave.addActionListener(new ActionListener() {

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			System.out.println("Process Save");
		}
	}
);
}

	public static void main(String[] args) {
		JFrame frame = new AnonymousLitenerDemo();
		frame.setTitle("AnonymousListenerDemo");
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.pack();
		frame.setVisible(true);
		
	}

}