package parte2;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import Libreria.Archivotxt;

public class Practica03_c extends JFrame {

    private JTextField Tid;
    private JTextField Tcategoria;
    private JTextArea Tareacategoria;
    private Archivotxt archivo;
    private ArrayList<String[]> listaCategorias; 

    public Practica03_c() {
        
        setTitle("Administración de Categorías");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        
        JPanel PanelFormulario = new JPanel();
        PanelFormulario.setLayout(new GridLayout(2, 2));

        JLabel labelID = new JLabel("ID:");
        JLabel labelCategoria = new JLabel("Categoría:");

        Tid = new JTextField();
        Tcategoria = new JTextField();

        PanelFormulario.add(labelID);
        PanelFormulario.add(Tid);
        PanelFormulario.add(labelCategoria);
        PanelFormulario.add(Tcategoria);

        add(PanelFormulario, BorderLayout.NORTH);

        
        Tareacategoria = new JTextArea();
        JScrollPane scrollPane = new JScrollPane(Tareacategoria);
        add(scrollPane, BorderLayout.CENTER);

        
        JPanel PanelBotones = new JPanel();
        JButton Bagregar = new JButton("Agregar");
        JButton Beliminar = new JButton("Eliminar");
        JButton Bsalir = new JButton("Salir");
        JButton Bcargar = new JButton("Cargar");

        PanelBotones.add(Bagregar);
        PanelBotones.add(Beliminar);
        PanelBotones.add(Bcargar);
        PanelBotones.add(Bsalir);
        add(PanelBotones, BorderLayout.SOUTH);

 
        archivo = new Archivotxt("categorias.txt");

     
        Bcargar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                listaCategorias = archivo.cargar();
                cargarCategorias(listaCategorias);
            }
        });

        
        Bagregar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String id = Tid.getText();
                String categoria = Tcategoria.getText();

                if (!id.isEmpty() && !categoria.isEmpty()) {
                    String nuevaCategoria = id + "," + categoria;
                    archivo.guardar(nuevaCategoria + "\n"); 
                    Tareacategoria.append("ID: " + id + ", Categoría: " + categoria + "\n"); 
                    Tcategoria.setText("");  
                } else {
                    JOptionPane.showMessageDialog(null, "Por favor, ingrese un ID y una Categoría.");
                }
            }
        });

        
        Beliminar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String id = Tid.getText();
                if (id.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Por favor, ingrese el ID de la categoría a eliminar.");
                    return;
                }

            
                boolean eliminado = false;
                for (int i = 0; i < listaCategorias.size(); i++) {
                    if (listaCategorias.get(i)[0].equals(id)) {
                        listaCategorias.remove(i);
                        eliminado = true;
                        break;
                    }
                }

                if (eliminado) {
                
                    StringBuilder contenidoNuevo = new StringBuilder();
                    for (String[] categoria : listaCategorias) {
                        contenidoNuevo.append(categoria[0]).append(",").append(categoria[1]).append("\n");
                    }
                    archivo.guardar(contenidoNuevo.toString());

                    
                    cargarCategorias(listaCategorias);
                    JOptionPane.showMessageDialog(null, "Categoría eliminada exitosamente.");
                } else {
                    JOptionPane.showMessageDialog(null, "No se encontró una categoría con el ID proporcionado.");
                }
            }
        });

        
        Bsalir.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
    }

    public void cargarCategorias(ArrayList<String[]> categoriasString) {
        Tareacategoria.setText(""); 
        for (String[] categoriaString : categoriasString) {
            String idCategoria = categoriaString[0];
            String nombreCategoria = categoriaString[1];
            Tareacategoria.append("ID: " + idCategoria + ", Categoría: " + nombreCategoria + "\n");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new Practica03_c().setVisible(true);
            }
        });
    }
}



