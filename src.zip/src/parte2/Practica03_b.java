package parte2;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Practica03_b extends JFrame {

    private JTextField Tid;
    private JTextField Tcategoria;
    private JTextArea Tareacategoria;
    private JButton Bagregar;
    private JButton Beliminar;
    private JButton Bsalir;

    public Practica03_b() {
        
        setTitle("Administración de Categorías");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());


        JPanel PanelFormulario = new JPanel();
        PanelFormulario.setLayout(new GridLayout(3, 2));

        
        JLabel labelID = new JLabel("ID:");
        JLabel labelCategoria = new JLabel("Categoría:");

        Tid = new JTextField();
        Tcategoria = new JTextField();
        Tareacategoria = new JTextArea();

        
        Tid.setEditable(false);
        Tcategoria.setEditable(false);
        Tareacategoria.setEditable(false);

       
        PanelFormulario.add(labelID);
        PanelFormulario.add(Tid);
        PanelFormulario.add(labelCategoria);
        PanelFormulario.add(Tcategoria);

        
        JPanel PanelBotones = new JPanel();
        Bagregar = new JButton("Agregar");
        Beliminar = new JButton("Eliminar");
        Bsalir = new JButton("Salir");

        PanelBotones.add(Bagregar);
        PanelBotones.add(Beliminar);
        PanelBotones.add(Bsalir);

       
        JScrollPane scrollPane = new JScrollPane(Tareacategoria);

        
        add(PanelFormulario, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(PanelBotones, BorderLayout.SOUTH);

        
        Bsalir.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
    }

    public static void main(String[] args) {
        
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new Practica03_b().setVisible(true);
            }
        });
    }
}
