package Unidad_1_Controlador;

import java.awt.event.ActionEvent;

import javax.swing.JDesktopPane;
import javax.swing.JInternalFrame.JDesktopIcon;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import java.awt.event.ActionListener;
import Unidad_1.Programa07_b2;

public class Programa07_c_controladorinternal implements ActionListener {

	Programa07_b2 nieto;
	JMenuBar barraprincipal;
	
	public Programa07_c_controladorinternal (String titulo, JMenuBar menu,JDesktopPane escritorio){
			nieto = new Programa07_b2();
			escritorio.add(nieto);
			nieto.setVisible(true);
			nieto.setTitle(titulo);
			this.barraprincipal = menu;
			this.barraprincipal.setVisible(false);
			this.nieto.Bsalir.addActionListener(this);
			
			
	}
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if (this.nieto.Bsalir == e.getSource()) {
			this.barraprincipal.setVisible(true);
			this.nieto.dispose();
		}
	}
	
}
