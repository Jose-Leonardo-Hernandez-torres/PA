package Unidad_1_Controlador;
import java.awt.event.ActionListener;

import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

import Unidad_1_Vista.Programa07_a_vista;
import Unidad_1.Programa07_b2;
import Unidad_1_Vista.Programa07_b_vista;

import java.awt.event.ActionEvent;

public class Controlador_b implements ActionListener{

	Programa07_b_vista VentanaPadre;
	Programa07_b2 hijo;
	
	public Controlador_b() {
		
		
		
		this.VentanaPadre = new Programa07_b_vista();
		this.VentanaPadre.setVisible(true);
		this.VentanaPadre.MOsalida.addActionListener(this);
		this.VentanaPadre.MOventas.addActionListener(this);
		this.VentanaPadre.MOreporteinventarios.addActionListener(this);
	}
	
	public void mensaje(JMenuItem item) {
		hijo = new Programa07_b2(item.getText());
		this.VentanaPadre.Descritorio.add(hijo);
		hijo.setVisible(true);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource() == this.VentanaPadre.MOventas) {
			this.mensaje(this.VentanaPadre.MOventas);
		}

		if (e.getSource() == this.VentanaPadre.MOreporteventas) {
			this.mensaje(this.VentanaPadre.MOreporteventas);
		}
		
		else {
			if (e.getSource() == this.VentanaPadre.MOsalida) {
				this.VentanaPadre.dispose();
			}
		}
	}
	
	
}
