package json;

public class ExamEjecucion {
	    public static void main(String[] args) {
	        // Crear el modelo
	        ExamModel model = new ExamModel();
	        
	        // Crear la vista
	        ExamView view = new ExamView();
	        
	        // Crear el controlador, pasándole el modelo y la vista
	        ExamController controller = new ExamController(model, view);
	        
	        // Mostrar la vista
	        view.setVisible(true);
	    
	}
}
