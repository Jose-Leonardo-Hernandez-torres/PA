package json;

import java.util.Random;

public class ExamModel {
    String examTitle;
    String header1, header2;
    int numberTerms;
    String[] term1 = new String[100];
    String[] term2 = new String[100];
    int numberTried, numberCorrect;
    int correctAnswer;
    Random myRandom = new Random();

    public String parseLeft(String s) {
        int cl;
        // find comma
        cl = s.indexOf(",");
        return (s.substring(0, cl));
    }

    public String parseRight(String s) {
        int cl;
        // find comma
        cl = s.indexOf(",");
        return (s.substring(cl + 1));
    }

    public String soundex(String w) {
        // Generates Soundex code for W based on Unicode value
        // Allows answers whose spelling is close, but not exact
        String wTemp, s = "";
        int l;
        int wPrev, wSnd, cIndex;
        // Load soundex function array
        int[] wSound = { 0, 1, 2, 3, 0, 1, 2, 0, 0, 2, 2, 4, 5, 5, 0, 1, 2, 6, 2, 3, 0, 1, 0, 2, 0, 2 };
        // Get uppercase word without punctuation
        wTemp = "";
        for (int i = 0; i < w.length(); i++) {
            if (Character.isLetter(w.charAt(i)))
                wTemp += w.charAt(i);
        }
        w = wTemp.toUpperCase();
        // Determine soundex code
        l = w.length();
        if (l > 0) {
            // First character is always first letter
            s = w.substring(0, 1);
            wPrev = (int) w.charAt(0) - 65;
            for (int i = 1; i < l && s.length() < 4; i++) {
                cIndex = (int) w.charAt(i) - 65;
                if (cIndex >= 0 && cIndex <= 25) {
                    wSnd = wSound[cIndex];
                    if (wSnd > 0 && wSnd != wSound[wPrev])
                        s += String.valueOf(wSnd);
                    wPrev = cIndex;
                }
            }
        }
        return (s + "0000").substring(0, 4);
    }

    public void nextQuestion() {
        boolean[] termUsed = new boolean[numberTerms];
        int[] index = new int[4];
        int j;

        // Generate the next question based on selected options
        correctAnswer = myRandom.nextInt(numberTerms);
    }
}