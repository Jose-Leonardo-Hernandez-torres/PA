package json;

import java.awt.event.*;
import javax.swing.*;
import java.io.*;

public class ExamController {
    private ExamModel model;
    private ExamView view;

    public ExamController(ExamModel model, ExamView view) {
        this.model = model;
        this.view = view;
        initController();
    }

    private void initController() {
        view.startButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                startExam();
            }
        });

        view.nextButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                nextQuestion();
            }
        });

        view.openMenuItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                openExamFile();
            }
        });

        view.exitMenuItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                exitApplication();
            }
        });
    }

    private void startExam() {
        view.startButton.setEnabled(false);
        view.nextButton.setEnabled(true);
        view.commentTextArea.setText("");
        model.numberCorrect = 0;
        model.numberTried = 0;
        nextQuestion();
    }

    private void nextQuestion() {
        model.nextQuestion();
        view.commentTextArea.setText("Correct answer is " + model.correctAnswer);
        model.numberTried++;
    }

    private void openExamFile() {
        JFileChooser myChooser = new JFileChooser();
        int result = myChooser.showOpenDialog(null);
        if (result == JFileChooser.APPROVE_OPTION) {
            try (BufferedReader in = new BufferedReader(new FileReader(myChooser.getSelectedFile()))) {
                model.examTitle = in.readLine();
                view.setTitle("Multiple Choice Exam - " + model.examTitle);
            } catch (IOException e) {
                JOptionPane.showMessageDialog(null, "Error opening file: " + e.getMessage());
            }
        }
    }

    private void exitApplication() {
        System.exit(0);
    }
}