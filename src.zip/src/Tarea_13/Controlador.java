package Tarea_13;

import javax.swing.*;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;

public class Controlador {
    private InterfazVisual vista;
    private boolean calcularPago;

    public Controlador(InterfazVisual vista) {
        this.vista = vista;

        // Asignar ActionListeners a los botones
        vista.getBcalcular().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                computeButtonActionPerformed(e);
            }
        });

        vista.getBnuevoPrestamo().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                newLoanButtonActionPerformed(e);
            }
        });

        vista.getBmeses().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                monthsButtonActionPerformed(e);
            }
        });

        vista.getBpagos().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                paymentButtonActionPerformed(e);
            }
        });

        vista.getBsalida().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                exitButtonActionPerformed(e);
            }
        });

        // Asignar ActionListeners a los campos de texto
        vista.getTFbalance().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                balanceTextFieldActionPerformed(e);
            }
        });

        vista.getTFinteres().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                interestTextFieldActionPerformed(e);
            }
        });

        vista.getTFmeses().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                monthsTextFieldActionPerformed(e);
            }
        });

        vista.getTFpagos().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                paymentTextFieldActionPerformed(e);
            }
        });
    }

    private void computeButtonActionPerformed(ActionEvent e) {
        double balance, interest, payment;
        int months;
        double monthlyInterest, multiplier;
        double loanBalance, finalPayment;

        if (validateDecimalNumber(vista.getTFbalance())) {
            balance = Double.valueOf(vista.getTFbalance().getText()).doubleValue();
        } else {
            JOptionPane.showConfirmDialog(null, "Entrada de Saldo del Préstamo inválida o vacía.\nPor favor corrige.",
                    "Error en la Entrada de Saldo", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        if (validateDecimalNumber(vista.getTFinteres())) {
            interest = Double.valueOf(vista.getTFinteres().getText()).doubleValue();
        } else {
            JOptionPane.showConfirmDialog(null, "Entrada de Tasa de Interés inválida o vacía.\nPor favor corrige.",
                    "Error en la Entrada de Interés", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        monthlyInterest = interest / 1200;

        if (calcularPago) {
            if (validateDecimalNumber(vista.getTFmeses())) {
                months = Integer.valueOf(vista.getTFmeses().getText()).intValue();
            } else {
                JOptionPane.showConfirmDialog(null,
                        "Entrada del Número de Pagos inválida o vacía.\nPor favor corrige.",
                        "Error en la Entrada de Número de Pagos", JOptionPane.DEFAULT_OPTION,
                        JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            if (interest == 0) {
                payment = balance / months;
            } else {
                multiplier = Math.pow(1 + monthlyInterest, months);
                payment = balance * monthlyInterest * multiplier / (multiplier - 1);
            }
            vista.getTFpagos().setText(new DecimalFormat("0.00").format(payment));
        } else {
            if (validateDecimalNumber(vista.getTFpagos())) {
                payment = Double.valueOf(vista.getTFpagos().getText()).doubleValue();
                if (payment <= (balance * monthlyInterest + 1.0)) {
                    if (JOptionPane.showConfirmDialog(null,
                            "El pago mínimo debe ser $"
                                    + new DecimalFormat("0.00").format((int) (balance * monthlyInterest + 1.0)) + "\n"
                                    + "¿Quieres usar el pago mínimo?",
                            "Error de Entrada", JOptionPane.YES_NO_OPTION,
                            JOptionPane.QUESTION_MESSAGE) == JOptionPane.YES_OPTION) {
                        vista.getTFpagos()
                                .setText(new DecimalFormat("0.00").format((int) (balance * monthlyInterest + 1.0)));
                        payment = Double.valueOf(vista.getTFpagos().getText()).doubleValue();
                    } else {
                        vista.getTFpagos().requestFocus();
                        return;
                    }
                }
            } else {
                JOptionPane.showConfirmDialog(null, "Entrada de Pago Mensual inválida o vacía.\nPor favor corrige.",
                        "Error en la Entrada de Pago", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            if (interest == 0) {
                months = (int) (balance / payment);
            } else {
                months = (int) ((Math.log(payment) - Math.log(payment - balance * monthlyInterest))
                        / Math.log(1 + monthlyInterest));
            }
            vista.getTFmeses().setText(String.valueOf(months));
        }

        payment = Double.valueOf(vista.getTFpagos().getText()).doubleValue();

        vista.getTAanalisis().setText("Saldo del Préstamo: $" + new DecimalFormat("0.00").format(balance));
        vista.getTAanalisis().append("\n" + "Tasa de Interés: " + new DecimalFormat("0.00").format(interest) + "%");

        loanBalance = balance;
        for (int paymentNumber = 1; paymentNumber <= months - 1; paymentNumber++) {
            loanBalance += loanBalance * monthlyInterest - payment;
        }

        finalPayment = loanBalance;
        if (finalPayment > payment) {
            loanBalance += loanBalance * monthlyInterest - payment;
            finalPayment = loanBalance;
            months++;
            vista.getTFmeses().setText(String.valueOf(months));
        }

        vista.getTAanalisis().append(
                "\n\n" + String.valueOf(months - 1) + " Pagos de $" + new DecimalFormat("0.00").format(payment));
        vista.getTAanalisis().append("\n" + "Pago Final de: $" + new DecimalFormat("0.00").format(finalPayment));
        vista.getTAanalisis().append("\n" + "Pagos Totales: $"
                + new DecimalFormat("0.00").format((months - 1) * payment + finalPayment));
        vista.getTAanalisis().append("\n" + "Interés Pagado: $"
                + new DecimalFormat("0.00").format((months - 1) * payment + finalPayment * balance));
        vista.getBcalcular().setEnabled(false);
        vista.getBnuevoPrestamo().setEnabled(true);
        vista.getBnuevoPrestamo().requestFocus();
    }

    private void newLoanButtonActionPerformed(ActionEvent e) {
        if (calcularPago) {
            vista.getTFpagos().setText("");
        } else {
            vista.getTFmeses().setText("");
        }
        vista.getTAanalisis().setText("");
        vista.getBcalcular().setEnabled(true);
        vista.getBnuevoPrestamo().setEnabled(false);
        vista.getTFbalance().requestFocus();
    }

    private void monthsButtonActionPerformed(ActionEvent e) {
        calcularPago = false;
        vista.getBpagos().setVisible(true);
        vista.getBmeses().setVisible(false);
        vista.getTFmeses().setText("");
        vista.getTFmeses().setEditable(false);
        vista.getTFmeses().setBackground(vista.lightYellow);
        vista.getTFmeses().setFocusable(false);
        vista.getTFpagos().setEditable(true);
        vista.getTFpagos().setBackground(Color.WHITE);
        vista.getTFpagos().setFocusable(true);
        vista.getBcalcular().setText("Calcular Número de Pagos");
        vista.getTFbalance().requestFocus();
    }

    private void paymentButtonActionPerformed(ActionEvent e) {
        calcularPago = true;
        vista.getBpagos().setVisible(false);
        vista.getBmeses().setVisible(true);
        vista.getTFmeses().setEditable(true);
        vista.getTFmeses().setBackground(Color.WHITE);
        vista.getTFmeses().setFocusable(true);
        vista.getTFpagos().setText("");
        vista.getTFpagos().setEditable(false);
        vista.getTFpagos().setBackground(vista.lightYellow);
        vista.getTFpagos().setFocusable(false);
        vista.getBcalcular().setText("Calcular Pago Mensual");
        vista.getTFbalance().requestFocus();
    }

    private void exitButtonActionPerformed(ActionEvent e) {
        System.exit(0);
    }

    private void balanceTextFieldActionPerformed(ActionEvent e) {
        vista.getTFbalance().transferFocus();
    }

    private void interestTextFieldActionPerformed(ActionEvent e) {
        vista.getTFinteres().transferFocus();
    }

    private void monthsTextFieldActionPerformed(ActionEvent e) {
        vista.getTFmeses().transferFocus();
    }

    private void paymentTextFieldActionPerformed(ActionEvent e) {
        vista.getTFpagos().transferFocus();
    }

    private boolean validateDecimalNumber(JTextField tf) {
        String s = tf.getText().trim();
        boolean hasDecimal = false;
        boolean valid = true;
        if (s.length() == 0) {
            valid = false;
        }
        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) == '.') {
                if (hasDecimal) {
                    valid = false;
                } else {
                    hasDecimal = true;
                }
            } else if (!Character.isDigit(s.charAt(i))) {
                valid = false;
            }
        }
        return valid;
    }
}
