package Tarea_13;

import javax.swing.*;
import java.awt.*;

//a2233336172
public class InterfazVisual extends JFrame {
    JLabel Lbalance = new JLabel();
    JTextField TFbalance = new JTextField();
    JLabel Linteres = new JLabel();
    JTextField TFinteres = new JTextField();
    JLabel Lmeses = new JLabel();
    JTextField TFmeses = new JTextField();
    JLabel Lpagos = new JLabel();
    JTextField TFpagos = new JTextField();
    JButton Bcalcular = new JButton();
    JButton BnuevoPrestamo = new JButton();
    JButton Bmeses = new JButton();
    JButton Bpagos = new JButton();
    JLabel Lanalisis = new JLabel();
    JTextArea TAanalisis = new JTextArea();
    JButton Bsalida = new JButton();
    Font miFont = new Font("Arial", Font.PLAIN, 16);
    Color lightYellow = new Color(255, 255, 128);

    public InterfazVisual() {
        // Configuración de la interfaz
        setTitle("Asistente de Préstamos");
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        getContentPane().setLayout(new GridBagLayout());
        GridBagConstraints gridConstraints;

        // Configuración de los componentes
        Lbalance.setText("Saldo del Préstamo");
        Lbalance.setFont(miFont);
        gridConstraints = new GridBagConstraints();
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;
        gridConstraints.anchor = GridBagConstraints.WEST;
        gridConstraints.insets = new Insets(10, 10, 0, 0);
        getContentPane().add(Lbalance, gridConstraints);
        TFbalance.setPreferredSize(new Dimension(100, 25));
        TFbalance.setHorizontalAlignment(SwingConstants.RIGHT);
        TFbalance.setFont(miFont);
        gridConstraints = new GridBagConstraints();
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 0;
        gridConstraints.insets = new Insets(10, 10, 0, 10);
        getContentPane().add(TFbalance, gridConstraints);

        Linteres.setText("Tasa de Interés");
        Linteres.setFont(miFont);
        gridConstraints = new GridBagConstraints();
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 1;
        gridConstraints.anchor = GridBagConstraints.WEST;
        gridConstraints.insets = new Insets(10, 10, 0, 0);
        getContentPane().add(Linteres, gridConstraints);
        TFinteres.setPreferredSize(new Dimension(100, 25));
        TFinteres.setHorizontalAlignment(SwingConstants.RIGHT);
        TFinteres.setFont(miFont);
        gridConstraints = new GridBagConstraints();
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 1;
        gridConstraints.insets = new Insets(10, 10, 0, 10);
        getContentPane().add(TFinteres, gridConstraints);

        Lmeses.setText("Número de Pagos");
        Lmeses.setFont(miFont);
        gridConstraints = new GridBagConstraints();
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 2;
        gridConstraints.anchor = GridBagConstraints.WEST;
        gridConstraints.insets = new Insets(10, 10, 0, 0);
        getContentPane().add(Lmeses, gridConstraints);
        TFmeses.setPreferredSize(new Dimension(100, 25));
        TFmeses.setHorizontalAlignment(SwingConstants.RIGHT);
        TFmeses.setFont(miFont);
        gridConstraints = new GridBagConstraints();
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 2;
        gridConstraints.insets = new Insets(10, 10, 0, 10);
        getContentPane().add(TFmeses, gridConstraints);

        Lpagos.setText("Pagos Mensuales");
        Lpagos.setFont(miFont);
        gridConstraints = new GridBagConstraints();
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 3;
        gridConstraints.anchor = GridBagConstraints.WEST;
        gridConstraints.insets = new Insets(10, 10, 0, 0);
        getContentPane().add(Lpagos, gridConstraints);
        TFpagos.setPreferredSize(new Dimension(100, 25));
        TFpagos.setHorizontalAlignment(SwingConstants.RIGHT);
        TFpagos.setFont(miFont);
        gridConstraints = new GridBagConstraints();
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 3;
        gridConstraints.insets = new Insets(10, 10, 0, 10);
        getContentPane().add(TFpagos, gridConstraints);

        Bcalcular.setText("Calcular Pago Mensual");
        gridConstraints = new GridBagConstraints();
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 4;
        gridConstraints.gridwidth = 2;
        gridConstraints.insets = new Insets(10, 0, 0, 0);
        getContentPane().add(Bcalcular, gridConstraints);

        BnuevoPrestamo.setText("Nuevo Análisis de Préstamo");
        BnuevoPrestamo.setEnabled(false);
        gridConstraints = new GridBagConstraints();
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 5;
        gridConstraints.gridwidth = 2;
        gridConstraints.insets = new Insets(10, 0, 10, 0);
        getContentPane().add(BnuevoPrestamo, gridConstraints);

        Bmeses.setText("X");
        Bmeses.setFocusable(false);
        gridConstraints = new GridBagConstraints();
        gridConstraints.gridx = 2;
        gridConstraints.gridy = 2;
        gridConstraints.insets = new Insets(10, 0, 0, 0);
        getContentPane().add(Bmeses, gridConstraints);

        Bpagos.setText("X");
        Bpagos.setFocusable(false);
        gridConstraints = new GridBagConstraints();
        gridConstraints.gridx = 2;
        gridConstraints.gridy = 3;
        gridConstraints.insets = new Insets(10, 0, 0, 0);
        getContentPane().add(Bpagos, gridConstraints);

        Lanalisis.setText("Análisis del Préstamo:");
        Lanalisis.setFont(miFont);
        gridConstraints = new GridBagConstraints();
        gridConstraints.gridx = 3;
        gridConstraints.gridy = 0;
        gridConstraints.anchor = GridBagConstraints.WEST;
        gridConstraints.insets = new Insets(0, 10, 0, 0);
        getContentPane().add(Lanalisis, gridConstraints);
        TAanalisis.setPreferredSize(new Dimension(250, 150));
        TAanalisis.setFocusable(false);
        TAanalisis.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        TAanalisis.setFont(new Font("Courier New", Font.PLAIN, 14));
        TAanalisis.setEditable(false);
        TAanalisis.setBackground(Color.WHITE);
        gridConstraints = new GridBagConstraints();
        gridConstraints.gridx = 3;
        gridConstraints.gridy = 1;
        gridConstraints.gridheight = 4;
        gridConstraints.insets = new Insets(0, 10, 0, 10);
        getContentPane().add(TAanalisis, gridConstraints);

        Bsalida.setText("Salir");
        Bsalida.setFocusable(false);
        gridConstraints = new GridBagConstraints();
        gridConstraints.gridx = 3;
        gridConstraints.gridy = 5;
        getContentPane().add(Bsalida, gridConstraints);

        pack();
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        setBounds((int) (0.5 * (screenSize.width - getWidth())), (int) (0.5 * (screenSize.height - getHeight())),
                getWidth(), getHeight());
    }

    public JTextField getTFbalance() {
        return TFbalance;
    }

    public JTextField getTFinteres() {
        return TFinteres;
    }

    public JTextField getTFmeses() {
        return TFmeses;
    }

    public JTextField getTFpagos() {
        return TFpagos;
    }

    public JButton getBcalcular() {
        return Bcalcular;
    }

    public JButton getBnuevoPrestamo() {
        return BnuevoPrestamo;
    }

    public JButton getBmeses() {
        return Bmeses;
    }

    public JButton getBpagos() {
        return Bpagos;
    }

    public JButton getBsalida() {
        return Bsalida;
    }

    public JTextArea getTAanalisis() {
        return TAanalisis;
    }
}
