package Tarea_13;
public class AsistentePrestamo1 {
    public static void main(String args[]) {
        InterfazVisual vista = new InterfazVisual();
        new Controlador(vista);
        vista.setVisible(true);
    }
}
