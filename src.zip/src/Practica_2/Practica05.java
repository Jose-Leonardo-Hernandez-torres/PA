package Practica_2;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Practica05 extends JFrame implements ActionListener {

    private JDesktopPane Escritorio;
    private JMenuBar BarraMenu;
    private JMenu MOperacion, MConfiguracion, MSalir;
    private JMenuItem SMInsumos, SMCategorias, SMSalida;
    private CardLayout cardLayout;
    private JPanel panelPrincipal;

    public Practica05() {
        // Configuración de la ventana principal
        setTitle("Ventana Principal Practica05");
        setBounds(100, 100, 800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Crear el DesktopPane
        Escritorio = new JDesktopPane();

        // Crear panel principal con CardLayout
        panelPrincipal = new JPanel();
        cardLayout = new CardLayout();
        panelPrincipal.setLayout(cardLayout);

        // Crear barra de menú
        BarraMenu = new JMenuBar();
        setJMenuBar(BarraMenu);

        // Crear menús
        MOperacion = new JMenu("Operación");
        MConfiguracion = new JMenu("Configuración");
        MSalir = new JMenu("Salir");

        // Añadir menús a la barra de menú
        BarraMenu.add(MOperacion);
        BarraMenu.add(MConfiguracion);
        BarraMenu.add(MSalir);

        // Crear submenús dentro de "Operación"
        SMInsumos = new JMenuItem("Insumos");
        MOperacion.add(SMInsumos);

        // Crear submenús dentro de "Configuración"
        SMCategorias = new JMenuItem("Categorías");
        MConfiguracion.add(SMCategorias);

        // Crear submenús dentro de "Salir"
        SMSalida = new JMenuItem("Salir");
        MSalir.add(SMSalida);

        // Añadir escuchas a los submenús
        SMCategorias.addActionListener(this);
        SMInsumos.addActionListener(this);
        SMSalida.addActionListener(this);

        // Añadir el panel principal con CardLayout al centro de la ventana
        add(panelPrincipal, BorderLayout.CENTER);

        // Añadir el Escritorio (JDesktopPane) a un panel gestionado por CardLayout
        panelPrincipal.add(Escritorio, "Escritorio");
        cardLayout.show(panelPrincipal, "Escritorio");

        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == SMSalida) {
            dispose();  // Cerrar la ventana principal
        } else if (e.getSource() == SMCategorias) {
            JOptionPane.showMessageDialog(this, "Llamando a Categorías");
        } else if (e.getSource() == SMInsumos) {
            Practica03_b hijo = new Practica03_b();  // Crear la ventana interna Practica03_b
            Escritorio.add(hijo);  // Añadirla al DesktopPane
            hijo.setVisible(true);  // Mostrar la ventana interna
        }
    }

    public static void main(String[] args) {
        new Practica05();
    }
}
