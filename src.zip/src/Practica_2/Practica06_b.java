package Practica_2;
import javax.swing.*;
import java.awt.*;

public class Practica06_b extends JFrame {

    public Practica06_b() {
        // Configuración de la ventana principal
        setTitle("Programa06_b con BorderLayout");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Panel norte con dos subpaneles
        JPanel panelNorte = new JPanel(new GridLayout(2, 1));  // Dos filas para organizar panel1 y panel2

        // Subpanel 1 para los campos "ID" e "Insumo"
        JPanel panel1 = new JPanel(new FlowLayout(FlowLayout.LEFT));  // Distribución horizontal
        JLabel lblID = new JLabel("ID:");
        JTextField tfID = new JTextField(10);  // Campo de texto para ID
        JLabel lblInsumo = new JLabel("Insumo:");
        JTextField tfInsumo = new JTextField(10);  // Campo de texto para Insumo
        panel1.add(lblID);
        panel1.add(tfID);
        panel1.add(lblInsumo);
        panel1.add(tfInsumo);

        // Subpanel 2 para el campo "Categoría" con una lista
        JPanel panel2 = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel lblCategoria = new JLabel("Categoría:");
        JTextField tfCategoria = new JTextField(10);  // Campo de texto para Categoría
        panel2.add(lblCategoria);
        panel2.add(tfCategoria);

        // Añadir paneles al panel norte
        panelNorte.add(panel1);
        panelNorte.add(panel2);

        // Panel centro con un área grande para la tabla de productos
        JPanel panelCentro = new JPanel(new BorderLayout());
        String[] columnas = {"ID", "Insumo", "Categoría"};
        JTable tablaProductos = new JTable(new Object[][]{}, columnas);  // Tabla vacía con las columnas
        JScrollPane scrollPaneTabla = new JScrollPane(tablaProductos);
        panelCentro.add(scrollPaneTabla, BorderLayout.CENTER);  // La tabla ocupa todo el espacio del centro

        // Panel sur con los botones
        JPanel panelSur = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JButton btnAgregar = new JButton("Agregar");
        JButton btnEliminar = new JButton("Eliminar");
        JButton btnSalir = new JButton("Salir");
        panelSur.add(btnAgregar);
        panelSur.add(btnEliminar);
        panelSur.add(btnSalir);

        // Añadir los paneles al BorderLayout
        add(panelNorte, BorderLayout.NORTH);
        add(panelCentro, BorderLayout.CENTER);
        add(panelSur, BorderLayout.SOUTH);

        // Hacer visible la ventana
        setVisible(true);
    }

    public static void main(String[] args) {
        new Practica06_b();
    }
}
