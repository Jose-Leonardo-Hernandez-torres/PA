package tarea8;
import java.awt.*;
import javax.swing.*;

public class Login {

    private JFrame frame;
    private JTextField txtUsuario;
    private JPasswordField passwordField;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Login window = new Login();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public Login() {
        initialize();
    }

    private void initialize() {
        frame = new JFrame();
        frame.setBounds(100, 100, 400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        JLabel lblFondo = new JLabel();
        lblFondo.setIcon(new ImageIcon("ruta/a/tu/imagen/fondo.jpg")); // Reemplazar con la ruta de tu imagen
        lblFondo.setBounds(0, 0, 400, 300);
        frame.getContentPane().add(lblFondo);

        JPanel panelLogin = new JPanel();
        panelLogin.setBounds(50, 100, 300, 150);
        lblFondo.add(panelLogin);
        panelLogin.setLayout(null);
        
        JLabel lblUsuario = new JLabel("Usuario:");
        lblUsuario.setBounds(10, 10, 80, 25);
        panelLogin.add(lblUsuario);
        
        txtUsuario = new JTextField();
        txtUsuario.setBounds(100, 10, 165, 25);
        panelLogin.add(txtUsuario);
        txtUsuario.setColumns(10);
        
        JLabel lblContrasena = new JLabel("Contraseña:");
        lblContrasena.setBounds(10, 45, 80, 25);
        panelLogin.add(lblContrasena);
        
        passwordField = new JPasswordField();
        passwordField.setBounds(100, 45, 165, 25);
        panelLogin.add(passwordField);
        
        JButton btnIniciar = new JButton("Iniciar");
        btnIniciar.setBounds(30, 100, 100, 25);
        panelLogin.add(btnIniciar);
        
        JButton btnRegistrar = new JButton("Registrarse");
        btnRegistrar.setBounds(150, 100, 100, 25);
        panelLogin.add(btnRegistrar);
    }
}
