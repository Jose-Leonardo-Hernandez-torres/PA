package tarea8;
import java.awt.*;
import javax.swing.*;

public class PuntodeVenta {

    private JFrame frame;
    private JTextField textField;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                	PuntodeVenta window = new PuntodeVenta();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public PuntodeVenta() {
        initialize();
    }

    private void initialize() {
        frame = new JFrame();
        frame.setBounds(100, 100, 450, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(new BorderLayout(0, 0));

        JPanel panelNumeros = new JPanel();
        frame.getContentPane().add(panelNumeros, BorderLayout.WEST);
        panelNumeros.setLayout(new GridLayout(4, 3, 5, 5));

        // Agregar botones numéricos
        String[] numeros = {"1", "2", "3", "4", "5", "6", "7", "8", "9", ".", "0", "C"};
        for (String num : numeros) {
            JButton button = new JButton(num);
            panelNumeros.add(button);
        }

        // Panel de Totales
        JPanel panelTotales = new JPanel();
        frame.getContentPane().add(panelTotales, BorderLayout.SOUTH);
        panelTotales.setLayout(new GridLayout(2, 2, 5, 5));

        JLabel lblSubtotal = new JLabel("Subtotal");
        JLabel lblIva = new JLabel("IVA");
        JLabel lblTotal = new JLabel("Total");
        JComboBox<String> comboBox = new JComboBox<>();
        comboBox.addItem("Método de Pago");

        panelTotales.add(lblSubtotal);
        panelTotales.add(new JLabel()); // Espacio vacío
        panelTotales.add(lblIva);
        panelTotales.add(comboBox);

        textField = new JTextField();
        frame.getContentPane().add(textField, BorderLayout.CENTER);
        textField.setColumns(10);
    }
}
