package tarea8;

import java.awt.*;
import javax.swing.*;

public class PagosWindow extends JFrame {
    private JTextField montoTextField;
    private JLabel restantesLabel;
    private JLabel cambioLabel;

    public PagosWindow() {
        setTitle("Pagos");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        getContentPane().setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        // Botón Volver
        JButton volverButton = new JButton("Volver");
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.WEST;
        getContentPane().add(volverButton, gbc);

        // Campo para ingresar el monto
        montoTextField = new JTextField("15.00", 10);
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.CENTER;
        getContentPane().add(montoTextField, gbc);

        // Labels para mostrar restantes y cambio
        restantesLabel = new JLabel("Restantes $0.00");
        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.EAST;
        getContentPane().add(restantesLabel, gbc);

        cambioLabel = new JLabel("Cambio $3.50");
        gbc.gridx = 2;
        gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.EAST;
        getContentPane().add(cambioLabel, gbc);

        // Teclado numérico
        JPanel keyboardPanel = new JPanel(new GridLayout(4, 3));
        String[] buttons = { "1", "2", "3", "4", "5", "6", "7", "8", "9", "+/-", "0", "X" };
        for (String text : buttons) {
            JButton button = new JButton(text);
            keyboardPanel.add(button);
        }
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 3;
        gbc.fill = GridBagConstraints.BOTH;
        getContentPane().add(keyboardPanel, gbc);

        // Botón Validar
        JButton validarButton = new JButton("Validar");
        gbc.gridx = 2;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.EAST;
        getContentPane().add(validarButton, gbc);

        // Panel derecho para cliente, facturas y propina
        JPanel rightPanel = new JPanel(new GridLayout(3, 1, 5, 5));
        JButton clienteButton = new JButton("Cliente");
        JButton facturasButton = new JButton("Facturas de clientes");
        JButton propinaButton = new JButton("Propina");

        rightPanel.add(clienteButton);
        rightPanel.add(facturasButton);
        rightPanel.add(propinaButton);

        gbc.gridx = 3;
        gbc.gridy = 1;
        gbc.gridheight = 2;
        gbc.fill = GridBagConstraints.BOTH;
        getContentPane().add(rightPanel, gbc);
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                PagosWindow frame = new PagosWindow();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}
