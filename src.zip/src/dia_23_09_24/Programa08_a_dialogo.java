package dia_23_09_24;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;

public class Programa08_a_dialogo extends JDialog {

	private static final long serialVersionUID = 1L;
	private final JPanel Panelsuperior = new JPanel();
	
	public  JButton Bsalvar,Bsalir;

	public static void main(String[] args) {
		try {
			Programa08_a_dialogo dialog = new Programa08_a_dialogo();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	
	public Programa08_a_dialogo() {
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		Panelsuperior.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(Panelsuperior, BorderLayout.CENTER);
		GridBagLayout gbl_panelsuperior = new GridBagLayout();
		gbl_panelsuperior.columnWidths = new int[]{0, 0};
		gbl_panelsuperior.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0, 0};
		gbl_panelsuperior.columnWeights = new double[]{1.0, Double.MIN_VALUE};
		gbl_panelsuperior.rowWeights = new double[]{1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, Double.MIN_VALUE};
		Panelsuperior.setLayout(gbl_panelsuperior);
		{
			JPanel panel = new JPanel();
			GridBagConstraints gbc_panel = new GridBagConstraints();
			gbc_panel.gridheight = 7;
			gbc_panel.insets = new Insets(0, 0, 5, 0);
			gbc_panel.fill = GridBagConstraints.BOTH;
			gbc_panel.gridx = 0;
			gbc_panel.gridy = 0;
			Panelsuperior.add(panel, gbc_panel);
		}
		{
			JPanel PanelInferior = new JPanel();
			getContentPane().add(PanelInferior, BorderLayout.SOUTH);
			GridBagLayout gbl_PanelInferior = new GridBagLayout();
			gbl_PanelInferior.columnWidths = new int[]{298, 61, 65, 0};
			gbl_PanelInferior.rowHeights = new int[]{23, 0};
			gbl_PanelInferior.columnWeights = new double[]{0.0, 0.0, 0.0, Double.MIN_VALUE};
			gbl_PanelInferior.rowWeights = new double[]{0.0, Double.MIN_VALUE};
			PanelInferior.setLayout(gbl_PanelInferior);
			{
				JButton Bsalvar_1 = new JButton("salvar");
				Bsalvar_1.setActionCommand("OK");
				GridBagConstraints gbc_Bsalvar_1 = new GridBagConstraints();
				gbc_Bsalvar_1.anchor = GridBagConstraints.NORTHWEST;
				gbc_Bsalvar_1.insets = new Insets(0, 0, 0, 5);
				gbc_Bsalvar_1.gridx = 1;
				gbc_Bsalvar_1.gridy = 0;
				PanelInferior.add(Bsalvar_1, gbc_Bsalvar_1);
				getRootPane().setDefaultButton(Bsalvar_1);
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.setActionCommand("Cancel");
				GridBagConstraints gbc_cancelButton = new GridBagConstraints();
				gbc_cancelButton.anchor = GridBagConstraints.NORTHWEST;
				gbc_cancelButton.gridx = 2;
				gbc_cancelButton.gridy = 0;
				PanelInferior.add(cancelButton, gbc_cancelButton);
			}
		}
	}

}
