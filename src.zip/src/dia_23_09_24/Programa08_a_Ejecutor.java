package dia_23_09_24;

import dia_23_09_24.Programa08_a_controlador;

public class Programa08_a_Ejecutor {

	static Programa08_a_controlador hijo;
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		hijo=new Programa08_a_controlador();
	}

}
