package dia_23_09_24;

import java.util.ArrayList;

public class Listaobjetos {
    ArrayList<Productos> lista;

    public Listaobjetos() {
        lista = new ArrayList<Productos>();
    }

    public void Insertar(Productos info) {
        this.lista.add(info);
    }

    public Object[][] getInfo() {    
        int Columnas = 6;
        int Filas = this.lista.size();
        Object[][] datos = new Object[Filas][Columnas];

        int fila = 0;
        for (Productos registro : lista) { // Cambiado a for-each
            Object[] dato = registro.getdatos();
            datos[fila] = dato; // Cambiado de datos a dato
            fila++;
        }
        return datos;
    }
}