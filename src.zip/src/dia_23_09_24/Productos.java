package dia_23_09_24;

import java.util.Objects;

public class Productos {
    private String IdProducto;
    private String Producto;
    private String Cantidad;
    private String Descripcion;
    private String Precio;
    private String Idcategoria;

    public Productos() {
 		super();
 		this.setIdProducto(null);;
 		this.setProducto(null);
 		this.setCantidad(null);
 		this.setDescripcion(null);
 		this.setPrecio(null);
 		this.setIdcategoria(null);
 	}
     
    
    @Override
	public String toString() {
		return this.getIdProducto();
	}


	public Productos(String idProducto, String producto, String cantidad, String descripcion, String precio,
			String idcategoria) {
		super();
		this.setIdProducto(idProducto);;
		this.setProducto(producto);
		this.setCantidad(cantidad);
		this.setDescripcion(descripcion);
		this.setPrecio(precio);
		this.setIdcategoria(idcategoria);
	}
    
    
    
	public String getIdProducto() {
		return IdProducto;
	}
	public void setIdProducto(String idProducto) {
		IdProducto = idProducto;
	}
	public String getProducto() {
		return Producto;
	}
	public void setProducto(String producto) {
		Producto = producto;
	}
	public String getCantidad() {
		return Cantidad;
	}
	public void setCantidad(String cantidad) {
		Cantidad = cantidad;
	}
	public String getDescripcion() {
		return Descripcion;
	}
	public void setDescripcion(String descripcion) {
		Descripcion = descripcion;
	}
	public String getPrecio() {
		return Precio;
	}
	public void setPrecio(String precio) {
		Precio = precio;
	}
	public String getIdcategoria() {
		return Idcategoria;
	}
	public void setIdcategoria(String idcategoria) {
		Idcategoria = idcategoria;
	}


public String[] columna() 
{return new String[]  {"id producto", "producto", "Descripcion", "Cantidad", "Precio","categoria"};}




public Object[] getdatos() 
{return new Object[]  {
		this.getIdProducto(),this.getIdProducto(),this.getDescripcion(),this.getCantidad(),this.getPrecio(),this.getIdcategoria()};

}

	@Override
	public boolean equals(Object obj) {
		boolean sucede=false;
		if (getClass() == obj.getClass()) {
			
			Productos otro = (Productos) obj;
			if(otro.getIdProducto()==this.getIdProducto())
				sucede= true;
		}
		
		return sucede;
		
		
	}
	
}

