package dia_23_09_24;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.table.DefaultTableModel;

import dia_23_09_24.Listaobjetos;
import dia_23_09_24.Productos;
import dia_23_09_24.Programa08_a;



public class  Programa08_a_controlador implements ActionListener {

	Programa08_a ventana;
	DefaultTableModel tablaproducto;
	Productos producto;
	Listaobjetos  Lista;
	
	public Programa08_a_controlador() {
		
		this.Lista=new Listaobjetos();
		this.Inicializartabla();
		
	ventana=new Programa08_a();
	ventana.Tproductos.setModel(tablaproducto);
	ventana.setVisible(true);	
	}
	
	
	public void Inicializartabla() {
		producto=new Productos();
		Productos obj1,obj2,obj3,obj4,obj5;
		
		obj1= new Productos ("001","Coca cola medio litro","bebida gaseosa","20","16","C001");
		this.Lista.Insertar(obj1);
	
		
		
		Object[][] datosproducto=this.Lista.getInfo();
		tablaproducto= new DefaultTableModel(datosproducto, producto.columna());
		
		
		
	}
	
	
	
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
	

}
