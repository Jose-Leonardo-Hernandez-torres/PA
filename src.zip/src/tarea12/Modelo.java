package tarea12;

import java.util.Random;

public class Modelo {
    private Random random = new Random();
    private int respuestaCorrecta;
    private String problema;
    private int cantidadIntentos;
    private int cantidadCorrectos;

    public Modelo() {
        this.cantidadIntentos = 0;
        this.cantidadCorrectos = 0;
    }

    public String obtenerProblema(int tipoOperacion, int factor) {
        int numero;
        switch (tipoOperacion) {
            case 0:
                numero = random.nextInt(10);
                respuestaCorrecta = numero + factor;
                problema = numero + " + " + factor + " = ?";
                break;
            case 1:
                numero = random.nextInt(10) + factor;
                respuestaCorrecta = numero - factor;
                problema = numero + " - " + factor + " = ?";
                break;
            case 2:
                numero = random.nextInt(10);
                respuestaCorrecta = numero * factor;
                problema = numero + " * " + factor + " = ?";
                break;
            case 3:
                int cociente = random.nextInt(10) + 1;
                respuestaCorrecta = cociente;
                numero = cociente * factor;
                problema = numero + " / " + factor + " = ?";
                break;
        }
        return problema;
    }

    public boolean verificarRespuesta(String respuesta) {
        return Integer.parseInt(respuesta) == respuestaCorrecta;
    }

    public void incrementarIntentos() {
        cantidadIntentos++;
    }

    public void incrementarCorrectos() {
        cantidadCorrectos++;
    }

    public int obtenerCantidadIntentos() {
        return cantidadIntentos;
    }

    public int obtenerCantidadCorrectos() {
        return cantidadCorrectos;
    }
}