package tarea12;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Random;
import java.text.DecimalFormat;

public class Flash extends JFrame {

    JLabel intentosLabel = new JLabel();
    JTextField intentosTextField = new JTextField();
    JLabel correctosLabel = new JLabel();
    JTextField correctosTextField = new JTextField();
    JLabel problemaLabel = new JLabel();
    JLabel divisorLabel = new JLabel();
    JPanel tipoPanel = new JPanel();
    JCheckBox[] tipoCheckBox = new JCheckBox[4];
    JPanel factorPanel = new JPanel();
    ButtonGroup factorButtonGroup = new ButtonGroup();
    JRadioButton[] factorRadioButton = new JRadioButton[11];
    JPanel temporizadorPanel = new JPanel();
    ButtonGroup temporizadorButtonGroup = new ButtonGroup();
    JRadioButton[] temporizadorRadioButton = new JRadioButton[3];
    JTextField temporizadorTextField = new JTextField();
    JScrollBar temporizadorScrollBar = new JScrollBar();
    JButton iniciarButton = new JButton();
    JButton salirButton = new JButton();
    Timer problemasTimer;

    Font miFuente = new Font("Arial", Font.PLAIN, 18);
    Color azulClaro = new Color(192, 192, 255);
    Random miRandom = new Random();

    int numeroIntentos, numeroCorrectos;
    int respuestaCorrecta, numeroDigitos;
    String problema;
    String tuRespuesta;
    int numeroDigito;
    int tiempoProblema;

    public static void main(String[] args) {
        // Crear marco
        new Flash().setVisible(true);
    }

    public Flash() {
        // Constructor del marco
        setTitle("Tarjetas de Matemáticas");
        getContentPane().setBackground(new Color(255, 255, 192));
        setResizable(false);

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent evt) {
                exitForm(evt);
            }
        });

        getContentPane().setLayout(new GridBagLayout());
        GridBagConstraints gridConstraints;

        intentosLabel.setText("Intentos:");
        intentosLabel.setFont(miFuente);
        gridConstraints = new GridBagConstraints();
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;
        gridConstraints.anchor = GridBagConstraints.WEST;
        gridConstraints.insets = new Insets(10, 10, 0, 10);
        getContentPane().add(intentosLabel, gridConstraints);

        intentosTextField.setText("0");
        intentosTextField.setPreferredSize(new Dimension(90, 30));
        intentosTextField.setEditable(false);
        intentosTextField.setBackground(Color.RED);
        intentosTextField.setForeground(Color.YELLOW);
        intentosTextField.setHorizontalAlignment(SwingConstants.CENTER);
        intentosTextField.setFont(miFuente);
        gridConstraints = new GridBagConstraints();
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 0;
        gridConstraints.insets = new Insets(10, 0, 0, 0);
        getContentPane().add(intentosTextField, gridConstraints);

        correctosLabel.setText("Correctos:");
        correctosLabel.setFont(miFuente);
        gridConstraints = new GridBagConstraints();
        gridConstraints.gridx = 2;
        gridConstraints.gridy = 0;
        gridConstraints.anchor = GridBagConstraints.EAST;
        gridConstraints.insets = new Insets(10, 10, 0, 10);
        getContentPane().add(correctosLabel, gridConstraints);

        correctosTextField.setText("0");
        correctosTextField.setPreferredSize(new Dimension(90, 30));
        correctosTextField.setEditable(false);
        correctosTextField.setBackground(Color.RED);
        correctosTextField.setForeground(Color.YELLOW);
        correctosTextField.setHorizontalAlignment(SwingConstants.CENTER);
        correctosTextField.setFont(miFuente);
        gridConstraints = new GridBagConstraints();
        gridConstraints.gridx = 3;
        gridConstraints.gridy = 0;
        gridConstraints.insets = new Insets(10, 0, 0, 0);
        getContentPane().add(correctosTextField, gridConstraints);

        problemaLabel.setText("");
        problemaLabel.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        problemaLabel.setPreferredSize(new Dimension(450, 100));
        problemaLabel.setBackground(Color.WHITE);
        problemaLabel.setOpaque(true);
        problemaLabel.setFont(new Font("Comic Sans MS", Font.PLAIN, 48));
        problemaLabel.setHorizontalAlignment(SwingConstants.CENTER);
        gridConstraints = new GridBagConstraints();
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 1;
        gridConstraints.gridwidth = 5;
        gridConstraints.insets = new Insets(10, 10, 0, 10);
        getContentPane().add(problemaLabel, gridConstraints);

        problemaLabel.addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                problemaLabelKeyPressed(e);
            }
        });

        divisorLabel.setPreferredSize(new Dimension(450, 10));
        divisorLabel.setBackground(Color.RED);
        divisorLabel.setOpaque(true);
        gridConstraints = new GridBagConstraints();
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 2;
        gridConstraints.gridwidth = 5;
        gridConstraints.insets = new Insets(10, 10, 10, 10);
        getContentPane().add(divisorLabel, gridConstraints);

        UIManager.put("TitledBorder.font", new Font("Arial", Font.BOLD, 14));
        tipoPanel.setPreferredSize(new Dimension(130, 130));
        tipoPanel.setBorder(BorderFactory.createTitledBorder("Tipo:"));
        tipoPanel.setBackground(azulClaro);
        tipoPanel.setLayout(new GridBagLayout());
        gridConstraints = new GridBagConstraints();
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 3;
        gridConstraints.gridwidth = 2;
        gridConstraints.anchor = GridBagConstraints.NORTH;
        getContentPane().add(tipoPanel, gridConstraints);

        for (int i = 0; i < 4; i++) {
            tipoCheckBox[i] = new JCheckBox();
            tipoCheckBox[i].setBackground(azulClaro);
            gridConstraints = new GridBagConstraints();
            gridConstraints.gridx = 0;
            gridConstraints.gridy = i;
            gridConstraints.anchor = GridBagConstraints.WEST;
            tipoPanel.add(tipoCheckBox[i], gridConstraints);
        }

        tipoCheckBox[0].setText("Suma");
        tipoCheckBox[1].setText("Resta");
        tipoCheckBox[2].setText("Multiplicación");
        tipoCheckBox[3].setText("División");
        tipoCheckBox[0].setSelected(true);

        factorPanel.setPreferredSize(new Dimension(130, 130));
        factorPanel.setBorder(BorderFactory.createTitledBorder("Factor:"));
        factorPanel.setBackground(azulClaro);
        factorPanel.setLayout(new GridBagLayout());
        gridConstraints = new GridBagConstraints();
        gridConstraints.gridx = 2;
        gridConstraints.gridy = 3;
        gridConstraints.gridwidth = 2;
        gridConstraints.anchor = GridBagConstraints.NORTH;
        getContentPane().add(factorPanel, gridConstraints);

        int x = 0;
        int y = 0;
        for (int i = 0; i < 11; i++) {
            factorRadioButton[i] = new JRadioButton();
            factorRadioButton[i].setText(String.valueOf(i));
            factorRadioButton[i].setBackground(azulClaro);
            factorButtonGroup.add(factorRadioButton[i]);
            gridConstraints = new GridBagConstraints();
            gridConstraints.gridx = x;
            gridConstraints.gridy = y;
            gridConstraints.anchor = GridBagConstraints.WEST;
            factorPanel.add(factorRadioButton[i], gridConstraints);

            x++;
            if (x > 1) {
                x = 0;
                y++;
            }
        }
        factorRadioButton[10].setText("Aleatorio");
        factorRadioButton[10].setSelected(true);

        temporizadorPanel.setPreferredSize(new Dimension(130, 130));
        temporizadorPanel.setBorder(BorderFactory.createTitledBorder("Temporizador:"));
        temporizadorPanel.setBackground(azulClaro);
        temporizadorPanel.setLayout(new GridBagLayout());
        gridConstraints = new GridBagConstraints();
        gridConstraints.gridx = 4;
        gridConstraints.gridy = 3;
        gridConstraints.insets = new Insets(0, 0, 0, 10);
        gridConstraints.anchor = GridBagConstraints.NORTH;
        getContentPane().add(temporizadorPanel, gridConstraints);

        for (int i = 0; i < 3; i++) {
            temporizadorRadioButton[i] = new JRadioButton();
            temporizadorRadioButton[i].setBackground(azulClaro);
            temporizadorButtonGroup.add(temporizadorRadioButton[i]);
            gridConstraints = new GridBagConstraints();
            gridConstraints.gridx = 0;
            gridConstraints.gridy = i;
            gridConstraints.gridwidth = 2;
            gridConstraints.anchor = GridBagConstraints.WEST;
            temporizadorPanel.add(temporizadorRadioButton[i], gridConstraints);
        }

        temporizadorRadioButton[0].setText("Sin límite de tiempo");
        temporizadorRadioButton[0].setSelected(true);
        temporizadorRadioButton[1].setText("Tiempo fijo:");
        temporizadorRadioButton[2].setText("Tiempo por dígito:");
        temporizadorTextField.setText("5.0");
        temporizadorTextField.setPreferredSize(new Dimension(45, 25));
        gridConstraints = new GridBagConstraints();
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 3;
        temporizadorPanel.add(temporizadorTextField, gridConstraints);

        temporizadorScrollBar.setMinimum(10);
        temporizadorScrollBar.setMaximum(1000);
        temporizadorScrollBar.setPreferredSize(new Dimension(20, 100));
        temporizadorScrollBar.setBackground(azulClaro);
        temporizadorScrollBar.setValue(500);
        gridConstraints = new GridBagConstraints();
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 1;
        gridConstraints.gridwidth = 1;
        gridConstraints.gridheight = 2;
        gridConstraints.anchor = GridBagConstraints.WEST;
        temporizadorPanel.add(temporizadorScrollBar, gridConstraints);

        temporizadorScrollBar.addAdjustmentListener(new AdjustmentListener() {
            public void adjustmentValueChanged(AdjustmentEvent e) {
                temporizadorScrollBarAdjustmentValueChanged(e);
            }
        });

        iniciarButton.setText("Iniciar");
        gridConstraints = new GridBagConstraints();
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 4;
        gridConstraints.insets = new Insets(10, 0, 10, 0);
        getContentPane().add(iniciarButton, gridConstraints);

        iniciarButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                iniciarButtonActionPerformed(e);
            }
        });

        salirButton.setText("Salir");
        gridConstraints = new GridBagConstraints();
        gridConstraints.gridx = 3;
        gridConstraints.gridy = 4;
        gridConstraints.insets = new Insets(10, 0, 10, 0);
        getContentPane().add(salirButton, gridConstraints);

        salirButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                salirButtonActionPerformed(e);
            }
        });

        problemasTimer = new Timer(1000, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                problemasTimerActionPerformed(e);
            }
        });

        pack();
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        setBounds((int) (0.5 * (screenSize.width - getWidth())),
                (int) (0.5 * (screenSize.height - getHeight())), getWidth(), getHeight());
    }

    private void temporizadorScrollBarAdjustmentValueChanged(AdjustmentEvent e) {
        DecimalFormat dosDigitos = new DecimalFormat("0.0");
        temporizadorTextField.setText(String.valueOf(dosDigitos.format(0.01 * temporizadorScrollBar.getValue())));
    }

    private void iniciarButtonActionPerformed(ActionEvent e) {
        boolean tipoSeleccionado = false;
        for (int i = 0; i < 4; i++) {
            if (tipoCheckBox[i].isSelected()) {
                tipoSeleccionado = true;
                break;
            }
        }
        if (!tipoSeleccionado) {
            JOptionPane.showConfirmDialog(null, "Por favor, selecciona al menos un tipo de problema", "Error",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.ERROR_MESSAGE);
            return;
        }

        numeroIntentos = 0;
        numeroCorrectos = 0;
        intentosTextField.setText(String.valueOf(numeroIntentos));
        correctosTextField.setText(String.valueOf(numeroCorrectos));

        iniciarButton.setEnabled(false);
        salirButton.setEnabled(false);
        tipoPanel.setEnabled(false);
        for (int i = 0; i < 4; i++) {
            tipoCheckBox[i].setEnabled(false);
        }

        factorPanel.setEnabled(false);
        for (int i = 0; i < 11; i++) {
            factorRadioButton[i].setEnabled(false);
        }

        temporizadorPanel.setEnabled(false);
        for (int i = 0; i < 3; i++) {
            temporizadorRadioButton[i].setEnabled(false);
        }
        temporizadorScrollBar.setEnabled(false);
        temporizadorTextField.setEnabled(false);

        problemaLabel.requestFocus();
        generarNuevoProblema();
    }

    private void salirButtonActionPerformed(ActionEvent e) {
        System.exit(0);
    }

    private void problemaLabelKeyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_ESCAPE) {
            problemasTimer.stop();
            problemaLabel.setText("");
            divisorLabel.setBackground(Color.RED);
            iniciarButton.setEnabled(true);
            salirButton.setEnabled(true);
            tipoPanel.setEnabled(true);
            for (int i = 0; i < 4; i++) {
                tipoCheckBox[i].setEnabled(true);
            }

            factorPanel.setEnabled(true);
            for (int i = 0; i < 11; i++) {
                factorRadioButton[i].setEnabled(true);
            }

            temporizadorPanel.setEnabled(true);
            for (int i = 0; i < 3; i++) {
                temporizadorRadioButton[i].setEnabled(true);
            }
            temporizadorScrollBar.setEnabled(true);
            temporizadorTextField.setEnabled(true);
            return;
        }

        if ((e.getKeyCode() == KeyEvent.VK_MINUS) || (e.getKeyCode() == KeyEvent.VK_BACK_SPACE)
                || (e.getKeyCode() == KeyEvent.VK_DELETE)) {
            return;
        }

        if ((e.getKeyCode() == KeyEvent.VK_ENTER) && (problemaLabel.getText().length() > 0)) {
            try {
                tuRespuesta = problemaLabel.getText();
                if (Integer.parseInt(tuRespuesta) == respuestaCorrecta) {
                    divisorLabel.setBackground(Color.GREEN);
                    numeroCorrectos++;
                    correctosTextField.setText(String.valueOf(numeroCorrectos));
                } else {
                    divisorLabel.setBackground(Color.RED);
                }
                numeroIntentos++;
                intentosTextField.setText(String.valueOf(numeroIntentos));
                generarNuevoProblema();
            } catch (NumberFormatException ex) {
                problemaLabel.setText("");
            }
        } else if (e.getKeyCode() >= KeyEvent.VK_0 && e.getKeyCode() <= KeyEvent.VK_9) {
            problemaLabel.setText(problemaLabel.getText() + e.getKeyChar());
        }
    }

    private void problemasTimerActionPerformed(ActionEvent e) {
        tiempoProblema--;
        divisorLabel.setBackground(tiempoProblema % 2 == 0 ? Color.RED : Color.WHITE);
        if (tiempoProblema == 0) {
            problemasTimer.stop();
            divisorLabel.setBackground(Color.RED);
            JOptionPane.showConfirmDialog(null, "¡Se acabó el tiempo! La respuesta correcta era: " + respuestaCorrecta,
                    "Tiempo Fuera", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE);
            generarNuevoProblema();
        }
    }

    private void exitForm(WindowEvent evt) {
        System.exit(0);
    }

    private void generarNuevoProblema() {
        String[] tipoOperaciones = {"+", "-", "*", "/"};
        int tipoSeleccionado = -1;
        while (tipoSeleccionado == -1) {
            int tipoAleatorio = miRandom.nextInt(4);
            if (tipoCheckBox[tipoAleatorio].isSelected()) {
                tipoSeleccionado = tipoAleatorio;
            }
        }

        int factor = -1;
        for (int i = 0; i < 11; i++) {
            if (factorRadioButton[i].isSelected()) {
                factor = i;
                break;
            }
        }
        if (factor == 10) {
            factor = miRandom.nextInt(10);
        }

        int numero1, numero2;
        switch (tipoSeleccionado) {
            case 0: // Suma
                numero1 = miRandom.nextInt(10 * factor + 1);
                numero2 = miRandom.nextInt(10 * factor + 1);
                respuestaCorrecta = numero1 + numero2;
                problema = numero1 + " + " + numero2;
                break;

            case 1: // Resta
                numero1 = miRandom.nextInt(10 * factor + 1);
                numero2 = miRandom.nextInt(10 * factor + 1);
                if (numero2 > numero1) {
                    int temp = numero1;
                    numero1 = numero2;
                    numero2 = temp;
                }
                respuestaCorrecta = numero1 - numero2;
                problema = numero1 + " - " + numero2;
                break;

            case 2: // Multiplicación
                numero1 = miRandom.nextInt(factor + 1);
                numero2 = miRandom.nextInt(10 * factor + 1);
                respuestaCorrecta = numero1 * numero2;
                problema = numero1 + " * " + numero2;
                break;

            case 3: // División
                numero2 = miRandom.nextInt(factor + 1) + 1;
                respuestaCorrecta = miRandom.nextInt(10 * factor + 1);
                numero1 = respuestaCorrecta * numero2;
                problema = numero1 + " / " + numero2;
                break;

            default:
                problema = "Error";
                respuestaCorrecta = 0;
        }

        problemaLabel.setText(problema);
        problemaLabel.setHorizontalAlignment(SwingConstants.CENTER);

        tiempoProblema = (int) (Double.parseDouble(temporizadorTextField.getText()) * 10);
        divisorLabel.setBackground(Color.RED);
        problemasTimer.start();
    }
}
