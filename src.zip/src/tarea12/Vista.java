package tarea12;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class Vista extends JFrame {
    private JLabel etiquetaIntentos = new JLabel("Intentos:");
    private JTextField campoIntentos = new JTextField("0");
    private JLabel etiquetaCorrectos = new JLabel("Correctos:");
    private JTextField campoCorrectos = new JTextField("0");
    private JLabel etiquetaProblema = new JLabel("El problema aparecerá aquí");
    private JTextField campoRespuesta = new JTextField(10);
    private JButton botonIniciar = new JButton("Iniciar Práctica");
    private JButton botonSalir = new JButton("Salir");
    private JButton botonEnviar = new JButton("Enviar Respuesta");

    public Vista() {
        setTitle("Flash Card Math");
        setLayout(new GridBagLayout());
        setResizable(false);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        inicializarComponentes();
    }

    private void inicializarComponentes() {
        campoIntentos.setEditable(false);
        campoCorrectos.setEditable(false);

        GridBagConstraints gbc = new GridBagConstraints();

        gbc.gridx = 0; gbc.gridy = 0;
        add(etiquetaIntentos, gbc);

        gbc.gridx = 1; 
        add(campoIntentos, gbc);

        gbc.gridx = 2; 
        add(etiquetaCorrectos, gbc);

        gbc.gridx = 3; 
        add(campoCorrectos, gbc);

        gbc.gridx = 0; gbc.gridy = 1; gbc.gridwidth = 4;
        add(etiquetaProblema, gbc);

        gbc.gridy = 2; 
        gbc.gridwidth = 1;
        add(campoRespuesta, gbc);

        gbc.gridx = 1;
        add(botonEnviar, gbc);

        gbc.gridx = 2; 
        add(botonIniciar, gbc);

        gbc.gridx = 3; 
        add(botonSalir, gbc);
    }

    public void establecerCantidadIntentos(int cantidad) {
        campoIntentos.setText(String.valueOf(cantidad));
    }

    public void establecerCantidadCorrectos(int cantidad) {
        campoCorrectos.setText(String.valueOf(cantidad));
    }

    public void establecerProblema(String problema) {
        etiquetaProblema.setText(problema);
    }

    public String obtenerRespuesta() {
        return campoRespuesta.getText();
    }

    public void limpiarRespuesta() {
        campoRespuesta.setText("");
    }

    public void agregarListenerBotonIniciar(ActionListener listener) {
        botonIniciar.addActionListener(listener);
    }

    public void agregarListenerBotonEnviar(ActionListener listener) {
        botonEnviar.addActionListener(listener);
    }

    public void agregarListenerBotonSalir(ActionListener listener) {
        botonSalir.addActionListener(listener);
    }
}
