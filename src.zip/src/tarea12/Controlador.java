package tarea12;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

public class Controlador {
    private Modelo modelo;
    private Vista vista;

    public Controlador(Modelo modelo, Vista vista) {
        this.modelo = modelo;
        this.vista = vista;

        vista.agregarListenerBotonEnviar(new ListenerBotonIniciar());
        vista.agregarListenerBotonEnviar(new ListenerBotonEnviar());
        vista.agregarListenerBotonSalir(new ListenerBotonSalir());
    }

    class ListenerBotonIniciar implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            modelo.incrementarIntentos();
            vista.establecerCantidadIntentos(modelo.obtenerCantidadIntentos());
            generarNuevoProblema();
        }
    }

    class ListenerBotonEnviar implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            String respuesta = vista.obtenerRespuesta();

            if (respuesta.isEmpty()) {
                JOptionPane.showMessageDialog(vista, "Por favor, ingresa una respuesta.");
                return;
            }

            if (modelo.verificarRespuesta(respuesta)) {
                modelo.incrementarCorrectos();
                vista.establecerCantidadCorrectos(modelo.obtenerCantidadCorrectos());
                JOptionPane.showMessageDialog(vista, "¡Respuesta correcta!");
                generarNuevoProblema();
            } else {
                JOptionPane.showMessageDialog(vista, "Respuesta incorrecta. Intenta de nuevo.");
            }

            vista.limpiarRespuesta();
        }
    }

    private void generarNuevoProblema() {
        int tipoOperacion = (int) (Math.random() * 4);
        int factor = (int) (Math.random() * 10) + 1;
        vista.establecerProblema(modelo.obtenerProblema(tipoOperacion, factor));
    }

    class ListenerBotonSalir implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            System.exit(0);
        }
    }
}