package Tareas;

public class Programa05_a {

	static Crelog hijo;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		hijo=new Crelog();
	}

}