package Tareas;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

public class Crelog implements ActionListener, WindowListener{

	long tiempoinicial;
	long tiempodetenido;
	double tiempotranscurrido;
	
	public Crelog(){
		// TODO Auto-generated constructor stub		
		ventana=new Relog();
		ventana.setVisible(true);	
		this.ventana.Bsalida.addActionListener(this);
		this.ventana.Binicio.addActionListener(this);
		this.ventana.Bdetener.addActionListener(this);
		this.ventana.addWindowListener(this);
		this.iniciar(true);
		}
	
	public void iniciar(boolean accion) {
		this.ventana.Bdetener.setEnabled(!accion);
		this.ventana.Bsalida.setEnabled(accion);
		this.ventana.Binicio.setEnabled(accion);
	}
	public Relog ventana;

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
		if(e.getSource()==this.ventana.Binicio) {
			this.iniciar(false);
			this.tiempoinicial=System.currentTimeMillis();
			this.ventana.Tinicio.setText(String.valueOf(this.tiempoinicial));
		}
		else
			if(e.getSource()==this.ventana.Bdetener) {
				this.tiempodetenido=System.currentTimeMillis();
				this.ventana.Tdetener.setText(String.valueOf(this.tiempodetenido));
				this.tiempotranscurrido=(this.tiempodetenido-this.tiempoinicial)/1000;
				this.ventana.Ttranscurrido.setText(String.valueOf(this.tiempotranscurrido));
				this.iniciar(true);
			}
				if(e.getSource()==this.ventana.Bsalida) 
					this.ventana.dispose();
		
	}

	@Override
	public void windowOpened(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowClosing(WindowEvent e) {//5
		
		
	}

	@Override
	public void windowClosed(WindowEvent e) {//5
		
		this.ventana.dispose();
	}

	@Override
	public void windowIconified(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowDeiconified(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowActivated(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowDeactivated(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}
}