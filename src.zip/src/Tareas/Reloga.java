package Tareas;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.GridBagLayout;
import javax.swing.JButton;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JTextField;
import javax.swing.JLabel;

public class Reloga extends JFrame implements ActionListener{

	private static final long serialVersionUID = 1L;
	private JPanel Principal;
	public JTextField Tinicio, Tdetener, Ttranscurrido;
	public JButton Bdetener, Binicio, Bsalida; 
	private long tiempoinicio;


	/**
	 * Create the frame.
	 */
	public Reloga() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 392, 166);
		Principal = new JPanel();
		Principal.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(Principal);
		GridBagLayout gbl_principal = new GridBagLayout();
		gbl_principal.columnWidths = new int[]{0, 138, 114, 139, 0, 0};
		gbl_principal.rowHeights = new int[]{17, 21, 21, 21, 0, 0};
		gbl_principal.columnWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		gbl_principal.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		Principal.setLayout(gbl_principal);
		
		Binicio = new JButton("Iniciar relog");
		GridBagConstraints gbc_binicio = new GridBagConstraints();
		gbc_binicio.fill = GridBagConstraints.HORIZONTAL;
		gbc_binicio.insets = new Insets(0, 0, 5, 5);
		gbc_binicio.gridx = 1;
		gbc_binicio.gridy = 1;
		Principal.add(Binicio, gbc_binicio);
		
		JLabel lblNewLabel = new JLabel("Iniciar");
		GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
		gbc_lblNewLabel.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel.gridx = 2;
		gbc_lblNewLabel.gridy = 1;
		Principal.add(lblNewLabel, gbc_lblNewLabel);
		
		Tinicio = new JTextField();
		GridBagConstraints gbc_tinicio = new GridBagConstraints();
		gbc_tinicio.fill = GridBagConstraints.HORIZONTAL;
		gbc_tinicio.insets = new Insets(0, 0, 5, 5);
		gbc_tinicio.gridx = 3;
		gbc_tinicio.gridy = 1;
		Principal.add(Tinicio, gbc_tinicio);
		Tinicio.setColumns(10);
		
		Bdetener = new JButton("Detener relog");
		Bdetener.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		GridBagConstraints gbc_bdetener = new GridBagConstraints();
		gbc_bdetener.fill = GridBagConstraints.HORIZONTAL;
		gbc_bdetener.insets = new Insets(0, 0, 5, 5);
		gbc_bdetener.gridx = 1;
		gbc_bdetener.gridy = 2;
		Principal.add(Bdetener, gbc_bdetener);
		
		JLabel lblNewLabel_1 = new JLabel("Detenerse");
		GridBagConstraints gbc_lblNewLabel_1 = new GridBagConstraints();
		gbc_lblNewLabel_1.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel_1.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_1.gridx = 2;
		gbc_lblNewLabel_1.gridy = 2;
		Principal.add(lblNewLabel_1, gbc_lblNewLabel_1);
		
		Tdetener = new JTextField();
		GridBagConstraints gbc_tdetener = new GridBagConstraints();
		gbc_tdetener.fill = GridBagConstraints.HORIZONTAL;
		gbc_tdetener.insets = new Insets(0, 0, 5, 5);
		gbc_tdetener.gridx = 3;
		gbc_tdetener.gridy = 2;
		Principal.add(Tdetener, gbc_tdetener);
		Tdetener.setColumns(10);
		
		Bsalida = new JButton("Salida");
		GridBagConstraints gbc_bsalida = new GridBagConstraints();
		gbc_bsalida.fill = GridBagConstraints.HORIZONTAL;
		gbc_bsalida.insets = new Insets(0, 0, 5, 5);
		gbc_bsalida.gridx = 1;
		gbc_bsalida.gridy = 3;
		Principal.add(Bsalida, gbc_bsalida);
		
		JLabel lblNewLabel_2 = new JLabel("Tiempo transcurrido (seg)");
		GridBagConstraints gbc_lblNewLabel_2 = new GridBagConstraints();
		gbc_lblNewLabel_2.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel_2.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_2.gridx = 2;
		gbc_lblNewLabel_2.gridy = 3;
		Principal.add(lblNewLabel_2, gbc_lblNewLabel_2);
		
		Ttranscurrido = new JTextField();
		GridBagConstraints gbc_ttranscurrido = new GridBagConstraints();
		gbc_ttranscurrido.fill = GridBagConstraints.HORIZONTAL;
		gbc_ttranscurrido.insets = new Insets(0, 0, 5, 5);
		gbc_ttranscurrido.gridx = 3;
		gbc_ttranscurrido.gridy = 3;
		Principal.add(Ttranscurrido, gbc_ttranscurrido);
		Ttranscurrido.setColumns(10);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
		if (e.getSource()==Binicio) 
		{}
			else
			if(e.getSource()==Bdetener)
			{}
			else
			if(e.getSource()==Bsalida) this.dispose();
	}

}