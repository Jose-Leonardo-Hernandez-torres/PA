package Tareas;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.GridBagLayout;
import javax.swing.JLabel;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class RelojDual extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField totalTimeTextField;
	private JTextField runningTimeTextField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RelojDual frame = new RelojDual();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public RelojDual() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[]{0, 0, 0};
		gbl_contentPane.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0};
		gbl_contentPane.columnWeights = new double[]{1.0, 0.0, Double.MIN_VALUE};
		gbl_contentPane.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		contentPane.setLayout(gbl_contentPane);
		
		JLabel runningTimeLabel = new JLabel("Running Time");
		GridBagConstraints gbc_runningTimeLabel = new GridBagConstraints();
		gbc_runningTimeLabel.anchor = GridBagConstraints.NORTH;
		gbc_runningTimeLabel.insets = new Insets(0, 0, 5, 5);
		gbc_runningTimeLabel.gridx = 0;
		gbc_runningTimeLabel.gridy = 0;
		contentPane.add(runningTimeLabel, gbc_runningTimeLabel);
		
		runningTimeTextField = new JTextField();
		runningTimeTextField.setEditable(false);
		runningTimeTextField.setText("00:00:00");
		runningTimeTextField.setHorizontalAlignment(SwingConstants.CENTER);
		GridBagConstraints gbc_runningTimeTextField = new GridBagConstraints();
		gbc_runningTimeTextField.insets = new Insets(0, 0, 5, 5);
		gbc_runningTimeTextField.gridx = 0;
		gbc_runningTimeTextField.gridy = 1;
		contentPane.add(runningTimeTextField, gbc_runningTimeTextField);
		runningTimeTextField.setColumns(10);
		
		JLabel totalTimeLabel = new JLabel("Total Time");
		GridBagConstraints gbc_totalTimeLabel = new GridBagConstraints();
		gbc_totalTimeLabel.insets = new Insets(0, 0, 5, 5);
		gbc_totalTimeLabel.gridx = 0;
		gbc_totalTimeLabel.gridy = 2;
		contentPane.add(totalTimeLabel, gbc_totalTimeLabel);
		
		totalTimeTextField = new JTextField();
		totalTimeTextField.setEditable(false);
		totalTimeTextField.setHorizontalAlignment(SwingConstants.CENTER);
		totalTimeTextField.setText("00:00:00");
		GridBagConstraints gbc_totalTimeTextField = new GridBagConstraints();
		gbc_totalTimeTextField.insets = new Insets(0, 0, 5, 5);
		gbc_totalTimeTextField.gridx = 0;
		gbc_totalTimeTextField.gridy = 3;
		contentPane.add(totalTimeTextField, gbc_totalTimeTextField);
		totalTimeTextField.setColumns(10);
		
		JButton startStopButton = new JButton("Start");
		GridBagConstraints gbc_startStopButton = new GridBagConstraints();
		gbc_startStopButton.insets = new Insets(0, 0, 5, 5);
		gbc_startStopButton.gridx = 0;
		gbc_startStopButton.gridy = 4;
		contentPane.add(startStopButton, gbc_startStopButton);
		
		JButton resetButton = new JButton("Reset");
		GridBagConstraints gbc_resetButton = new GridBagConstraints();
		gbc_resetButton.insets = new Insets(0, 0, 5, 0);
		gbc_resetButton.gridx = 1;
		gbc_resetButton.gridy = 4;
		contentPane.add(resetButton, gbc_resetButton);
		
		JButton exitButton = new JButton("Exit");
		GridBagConstraints gbc_exitButton = new GridBagConstraints();
		gbc_exitButton.gridx = 1;
		gbc_exitButton.gridy = 5;
		contentPane.add(exitButton, gbc_exitButton);
	}

}
