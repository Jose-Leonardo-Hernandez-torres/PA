package Tareas;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.GridBagLayout;
import javax.swing.JButton;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class PRelog extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField startTextField;
	private JTextField stopTextField;
	private JTextField elapsedTextField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PRelog frame = new PRelog();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public PRelog() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[]{0, 0, 0, 0};
		gbl_contentPane.rowHeights = new int[]{0, 0, 0, 0};
		gbl_contentPane.columnWeights = new double[]{0.0, 0.0, 1.0, Double.MIN_VALUE};
		gbl_contentPane.rowWeights = new double[]{0.0, 0.0, 0.0, Double.MIN_VALUE};
		contentPane.setLayout(gbl_contentPane);
		
		JButton startButton = new JButton("Start Timing");
		GridBagConstraints gbc_startButton = new GridBagConstraints();
		gbc_startButton.insets = new Insets(0, 0, 5, 5);
		gbc_startButton.gridx = 0;
		gbc_startButton.gridy = 0;
		contentPane.add(startButton, gbc_startButton);
		
		JLabel startLabel = new JLabel("Start Time");
		GridBagConstraints gbc_startLabel = new GridBagConstraints();
		gbc_startLabel.anchor = GridBagConstraints.EAST;
		gbc_startLabel.insets = new Insets(0, 0, 5, 5);
		gbc_startLabel.gridx = 1;
		gbc_startLabel.gridy = 0;
		contentPane.add(startLabel, gbc_startLabel);
		
		startTextField = new JTextField();
		GridBagConstraints gbc_startTextField = new GridBagConstraints();
		gbc_startTextField.insets = new Insets(0, 0, 5, 0);
		gbc_startTextField.fill = GridBagConstraints.HORIZONTAL;
		gbc_startTextField.gridx = 2;
		gbc_startTextField.gridy = 0;
		contentPane.add(startTextField, gbc_startTextField);
		startTextField.setColumns(10);
		
		JButton stopButton = new JButton("Stop Button");
		GridBagConstraints gbc_stopButton = new GridBagConstraints();
		gbc_stopButton.insets = new Insets(0, 0, 5, 5);
		gbc_stopButton.gridx = 0;
		gbc_stopButton.gridy = 1;
		contentPane.add(stopButton, gbc_stopButton);
		
		JLabel stopLabel = new JLabel("Stop Time");
		GridBagConstraints gbc_stopLabel = new GridBagConstraints();
		gbc_stopLabel.anchor = GridBagConstraints.EAST;
		gbc_stopLabel.insets = new Insets(0, 0, 5, 5);
		gbc_stopLabel.gridx = 1;
		gbc_stopLabel.gridy = 1;
		contentPane.add(stopLabel, gbc_stopLabel);
		
		stopTextField = new JTextField();
		GridBagConstraints gbc_stopTextField = new GridBagConstraints();
		gbc_stopTextField.insets = new Insets(0, 0, 5, 0);
		gbc_stopTextField.fill = GridBagConstraints.HORIZONTAL;
		gbc_stopTextField.gridx = 2;
		gbc_stopTextField.gridy = 1;
		contentPane.add(stopTextField, gbc_stopTextField);
		stopTextField.setColumns(10);
		
		JButton exitButton = new JButton("Exit");
		GridBagConstraints gbc_exitButton = new GridBagConstraints();
		gbc_exitButton.insets = new Insets(0, 0, 0, 5);
		gbc_exitButton.gridx = 0;
		gbc_exitButton.gridy = 2;
		contentPane.add(exitButton, gbc_exitButton);
		
		JLabel elapsedLabel = new JLabel("Elapsed Time (sec)");
		GridBagConstraints gbc_elapsedLabel = new GridBagConstraints();
		gbc_elapsedLabel.anchor = GridBagConstraints.EAST;
		gbc_elapsedLabel.insets = new Insets(0, 0, 0, 5);
		gbc_elapsedLabel.gridx = 1;
		gbc_elapsedLabel.gridy = 2;
		contentPane.add(elapsedLabel, gbc_elapsedLabel);
		
		elapsedTextField = new JTextField();
		GridBagConstraints gbc_elapsedTextField = new GridBagConstraints();
		gbc_elapsedTextField.fill = GridBagConstraints.HORIZONTAL;
		gbc_elapsedTextField.gridx = 2;
		gbc_elapsedTextField.gridy = 2;
		contentPane.add(elapsedTextField, gbc_elapsedTextField);
		elapsedTextField.setColumns(10);
	}

}
