package Tareas;

import java.awt.EventQueue;

import javax.swing.*;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ejemploJframe_05_a2 extends JFrame implements ActionListener {

	static JLabel La,Lb,Lc;
	static JButton Bcalcular,Bsalir;
	static JTextField Ta,Th,Tb;
	
	public ejemploJframe_05_a2() {
		this.setLayout(new FlowLayout (FlowLayout.CENTER,3,3));
		this.setTitle("Layout FlowLayout Center");
		this.setBounds(10,10,550,100);
		JPanel Panel= new JPanel();
		
		La=new JLabel("Altura--->");
		Lb=new JLabel("Base--->");
		Lc=new JLabel("El area --->");
		
		Th=new JTextField("      ");
		Tb=new JTextField("      ");
		Ta=new JTextField("      ");
		
		Ta.setEditable(false);
		Bcalcular= new JButton();
		Bcalcular.setText("Calcular");
		Bcalcular.addActionListener(this);
		Bsalir= new JButton();
		Bsalir.setText("Salir");
		Bsalir.addActionListener(this);
		
		
	    Panel.add(La);
		Panel.add(Th);
		Panel.add(Lb);
		Panel.add(Tb);
		Panel.add(Bcalcular);
		Panel.add(Lc);
		Panel.add(Ta);
		Panel.add(Bsalir);
		
		add(Panel);
	}
	
	public static void main(String[] args) {
		ejemploJframe_05_a2 ventana=new ejemploJframe_05_a2();
		ventana.setVisible(true);
	}
	
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==Bcalcular) {
			double h,b,a;
			String Sh,Sb;
			Sh=Th.getText();
			Sb=Tb.getText();
			if(!Sh.isEmpty() && !Sh.isEmpty())
			{
				h=Double.parseDouble(Sh);
				b=Double.parseDouble(Sb);
				a=(h*b)/2;
				Ta.setText(String.valueOf(a));
			}
			else 
				JOptionPane.showMessageDialog(this, "LO SIENTO UNO O DOS TEXTOS ESTAN VACIOS");
		}
		else 
			if(e.getSource()==Bsalir)
			{
				
				System.exit(0);
			}
	}

}
